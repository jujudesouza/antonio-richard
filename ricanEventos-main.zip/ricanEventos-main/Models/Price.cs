
namespace ricanEventos.Models;

public class Price
{
  public decimal Value { get; set; }
  public string Category { get; set; } = string.Empty;

}