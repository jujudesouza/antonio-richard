
namespace ricanEventos.Models;

public class State
{
  public int Id { get; set; }
  public string Nome { get; set; }
  public string SiglaUf { get; set; }
}