

var user = {
  Name: "",
  Email: "",
  Password: "",
  CityPreference: "",
  EventFavorites: []
}