INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100015,11,'Alta Floresta Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100023,11,'Ariquemes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100031,11,'Cabixi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100049,11,'Cacoal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100056,11,'Cerejeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100064,11,'Colorado do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100072,11,'Corumbiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100080,11,'Costa Marques');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100098,11,'Espigão Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100106,11,'Guajará-Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100114,11,'Jaru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100122,11,'Ji-Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100130,11,'Machadinho Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100148,11,'Nova Brasilândia Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100155,11,'Ouro Preto do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100189,11,'Pimenta Bueno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100205,11,'Porto Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100254,11,'Presidente Médici');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100262,11,'Rio Crespo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100288,11,'Rolim de Moura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100296,11,'Santa Luzia Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100304,11,'Vilhena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100320,11,'São Miguel do Guaporé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100338,11,'Nova Mamoré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100346,11,'Alvorada Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100379,11,'Alto Alegre dos Parecis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100403,11,'Alto Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100452,11,'Buritis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100502,11,'Novo Horizonte do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100601,11,'Cacaulândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100700,11,'Campo Novo de Rondônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100809,11,'Candeias do Jamari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100908,11,'Castanheiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100924,11,'Chupinguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1100940,11,'Cujubim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101005,11,'Governador Jorge Teixeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101104,11,'Itapuã do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101203,11,'Ministro Andreazza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101302,11,'Mirante da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101401,11,'Monte Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101435,11,'Nova União');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101450,11,'Parecis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101468,11,'Pimenteiras do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101476,11,'Primavera de Rondônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101484,11,'São Felipe Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101492,11,'São Francisco do Guaporé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101500,11,'Seringueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101559,11,'Teixeirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101609,11,'Theobroma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101708,11,'Urupá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101757,11,'Vale do Anari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1101807,11,'Vale do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200013,12,'Acrelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200054,12,'Assis Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200104,12,'Brasiléia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200138,12,'Bujari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200179,12,'Capixaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200203,12,'Cruzeiro do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200252,12,'Epitaciolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200302,12,'Feijó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200328,12,'Jordão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200336,12,'Mâncio Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200344,12,'Manoel Urbano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200351,12,'Marechal Thaumaturgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200385,12,'Plácido de Castro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200393,12,'Porto Walter');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200401,12,'Rio Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200427,12,'Rodrigues Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200435,12,'Santa Rosa do Purus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200450,12,'Senador Guiomard');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200500,12,'Sena Madureira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200609,12,'Tarauacá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200708,12,'Xapuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1200807,12,'Porto Acre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300029,13,'Alvarães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300060,13,'Amaturá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300086,13,'Anamã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300102,13,'Anori');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300144,13,'Apuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300201,13,'Atalaia do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300300,13,'Autazes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300409,13,'Barcelos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300508,13,'Barreirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300607,13,'Benjamin Constant');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300631,13,'Beruri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300680,13,'Boa Vista do Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300706,13,'Boca do Acre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300805,13,'Borba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300839,13,'Caapiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1300904,13,'Canutama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301001,13,'Carauari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301100,13,'Careiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301159,13,'Careiro da Várzea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301209,13,'Coari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301308,13,'Codajás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301407,13,'Eirunepé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301506,13,'Envira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301605,13,'Fonte Boa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301654,13,'Guajará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301704,13,'Humaitá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301803,13,'Ipixuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301852,13,'Iranduba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301902,13,'Itacoatiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1301951,13,'Itamarati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302009,13,'Itapiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302108,13,'Japurá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302207,13,'Juruá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302306,13,'Jutaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302405,13,'Lábrea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302504,13,'Manacapuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302553,13,'Manaquiri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302603,13,'Manaus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302702,13,'Manicoré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302801,13,'Maraã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1302900,13,'Maués');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303007,13,'Nhamundá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303106,13,'Nova Olinda do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303205,13,'Novo Airão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303304,13,'Novo Aripuanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303403,13,'Parintins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303502,13,'Pauini');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303536,13,'Presidente Figueiredo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303569,13,'Rio Preto da Eva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303601,13,'Santa Isabel do Rio Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303700,13,'Santo Antônio do Içá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303809,13,'São Gabriel da Cachoeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303908,13,'São Paulo de Olivença');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1303957,13,'São Sebastião do Uatumã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304005,13,'Silves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304062,13,'Tabatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304104,13,'Tapauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304203,13,'Tefé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304237,13,'Tonantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304260,13,'Uarini');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304302,13,'Urucará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1304401,13,'Urucurituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400027,14,'Amajari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400050,14,'Alto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400100,14,'Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400159,14,'Bonfim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400175,14,'Cantá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400209,14,'Caracaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400233,14,'Caroebe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400282,14,'Iracema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400308,14,'Mucajaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400407,14,'Normandia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400456,14,'Pacaraima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400472,14,'Rorainópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400506,14,'São João da Baliza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400605,14,'São Luiz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1400704,14,'Uiramutã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500107,15,'Abaetetuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500131,15,'Abel Figueiredo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500206,15,'Acará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500305,15,'Afuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500347,15,'Água Azul do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500404,15,'Alenquer');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500503,15,'Almeirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500602,15,'Altamira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500701,15,'Anajás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500800,15,'Ananindeua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500859,15,'Anapu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500909,15,'Augusto Corrêa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1500958,15,'Aurora do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501006,15,'Aveiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501105,15,'Bagre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501204,15,'Baião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501253,15,'Bannach');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501303,15,'Barcarena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501402,15,'Belém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501451,15,'Belterra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501501,15,'Benevides');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501576,15,'Bom Jesus do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501600,15,'Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501709,15,'Bragança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501725,15,'Brasil Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501758,15,'Brejo Grande do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501782,15,'Breu Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501808,15,'Breves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501907,15,'Bujaru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1501956,15,'Cachoeira do Piriá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502004,15,'Cachoeira do Arari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502103,15,'Cametá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502152,15,'Canaã dos Carajás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502202,15,'Capanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502301,15,'Capitão Poço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502400,15,'Castanhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502509,15,'Chaves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502608,15,'Colares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502707,15,'Conceição do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502756,15,'Concórdia do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502764,15,'Cumaru do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502772,15,'Curionópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502806,15,'Curralinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502855,15,'Curuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502905,15,'Curuçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502939,15,'dom Eliseu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1502954,15,'Eldorado do Carajás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503002,15,'Faro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503044,15,'Floresta do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503077,15,'Garrafão do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503093,15,'Goianésia do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503101,15,'Gurupá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503200,15,'Igarapé-Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503309,15,'Igarapé-Miri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503408,15,'Inhangapi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503457,15,'Ipixuna do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503507,15,'Irituia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503606,15,'Itaituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503705,15,'Itupiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503754,15,'Jacareacanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503804,15,'Jacundá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1503903,15,'Juruti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504000,15,'Limoeiro do Ajuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504059,15,'Mãe do Rio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504109,15,'Magalhães Barata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504208,15,'Marabá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504307,15,'Maracanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504406,15,'Marapanim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504422,15,'Marituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504455,15,'Medicilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504505,15,'Melgaço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504604,15,'Mocajuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504703,15,'Moju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504752,15,'Mojuí dos Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504802,15,'Monte Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504901,15,'Muaná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504950,15,'Nova Esperança do Piriá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1504976,15,'Nova Ipixuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505007,15,'Nova Timboteua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505031,15,'Novo Progresso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505064,15,'Novo Repartimento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505106,15,'Óbidos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505205,15,'Oeiras do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505304,15,'Oriximiná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505403,15,'Ourém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505437,15,'Ourilândia do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505486,15,'Pacajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505494,15,'Palestina do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505502,15,'Paragominas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505536,15,'Parauapebas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505551,15,'Pau Darco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505601,15,'Peixe-Boi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505635,15,'Piçarra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505650,15,'Placas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505700,15,'Ponta de Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505809,15,'Portel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1505908,15,'Porto de Moz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506005,15,'Prainha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506104,15,'Primavera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506112,15,'Quatipuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506138,15,'Redenção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506161,15,'Rio Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506187,15,'Rondon do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506195,15,'Rurópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506203,15,'Salinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506302,15,'Salvaterra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506351,15,'Santa Bárbara do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506401,15,'Santa Cruz do Arari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506500,15,'Santa Izabel do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506559,15,'Santa Luzia do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506583,15,'Santa Maria das Barreiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506609,15,'Santa Maria do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506708,15,'Santana do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506807,15,'Santarém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1506906,15,'Santarém Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507003,15,'Santo Antônio do Tauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507102,15,'São Caetano de Odivelas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507151,15,'São domingos do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507201,15,'São domingos do Capim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507300,15,'São Félix do Xingu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507409,15,'São Francisco do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507458,15,'São Geraldo do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507466,15,'São João da Ponta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507474,15,'São João de Pirabas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507508,15,'São João do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507607,15,'São Miguel do Guamá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507706,15,'São Sebastião da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507755,15,'Sapucaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507805,15,'Senador José Porfírio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507904,15,'Soure');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507953,15,'Tailândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507961,15,'Terra Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1507979,15,'Terra Santa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508001,15,'Tomé-Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508035,15,'Tracuateua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508050,15,'Trairão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508084,15,'Tucumã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508100,15,'Tucuruí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508126,15,'Ulianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508159,15,'Uruará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508209,15,'Vigia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508308,15,'Viseu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508357,15,'Vitória do Xingu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1508407,15,'Xinguara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600055,16,'Serra do Navio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600105,16,'Amapá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600154,16,'Pedra Branca do Amapari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600204,16,'Calçoene');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600212,16,'Cutias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600238,16,'Ferreira Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600253,16,'Itaubal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600279,16,'Laranjal do Jari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600303,16,'Macapá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600402,16,'Mazagão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600501,16,'Oiapoque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600535,16,'Porto Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600550,16,'Pracuúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600600,16,'Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600709,16,'Tartarugalzinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1600808,16,'Vitória do Jari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1700251,17,'Abreulândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1700301,17,'Aguiarnópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1700350,17,'Aliança do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1700400,17,'Almas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1700707,17,'Alvorada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1701002,17,'Ananás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1701051,17,'Angico');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1701101,17,'Aparecida do Rio Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1701309,17,'Aragominas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1701903,17,'Araguacema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702000,17,'Araguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702109,17,'Araguaína');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702158,17,'Araguanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702208,17,'Araguatins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702307,17,'Arapoema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702406,17,'Arraias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702554,17,'Augustinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702703,17,'Aurora do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1702901,17,'Axixá do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703008,17,'Babaçulândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703057,17,'Bandeirantes do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703073,17,'Barra do Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703107,17,'Barrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703206,17,'Bernardo Sayão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703305,17,'Bom Jesus do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703602,17,'Brasilândia do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703701,17,'Brejinho de Nazaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703800,17,'Buriti do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703826,17,'Cachoeirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703842,17,'Campos Lindos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703867,17,'Cariri do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703883,17,'Carmolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703891,17,'Carrasco Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1703909,17,'Caseara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1704105,17,'Centenário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1704600,17,'Chapada de Areia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1705102,17,'Chapada da Natividade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1705508,17,'Colinas do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1705557,17,'Combinado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1705607,17,'Conceição do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1706001,17,'Couto Magalhães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1706100,17,'Cristalândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1706258,17,'Crixás do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1706506,17,'darcinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707009,17,'Dianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707108,17,'Divinópolis do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707207,17,'dois Irmãos do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707306,17,'Dueré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707405,17,'Esperantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707553,17,'Fátima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707652,17,'Figueirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1707702,17,'Filadélfia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1708205,17,'Formoso do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1708254,17,'Fortaleza do Tabocão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1708304,17,'Goianorte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1709005,17,'Goiatins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1709302,17,'Guaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1709500,17,'Gurupi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1709807,17,'Ipueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1710508,17,'Itacajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1710706,17,'Itaguatins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1710904,17,'Itapiratins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1711100,17,'Itaporã do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1711506,17,'Jaú do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1711803,17,'Juarina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1711902,17,'Lagoa da Confusão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1711951,17,'Lagoa do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712009,17,'Lajeado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712157,17,'Lavandeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712405,17,'Lizarda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712454,17,'Luzinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712504,17,'Marianópolis do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712702,17,'Mateiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1712801,17,'Maurilândia do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713205,17,'Miracema do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713304,17,'Miranorte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713601,17,'Monte do Carmo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713700,17,'Monte Santo do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713809,17,'Palmeiras do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1713957,17,'Muricilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1714203,17,'Natividade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1714302,17,'Nazaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1714880,17,'Nova Olinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715002,17,'Nova Rosalândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715101,17,'Novo Acordo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715150,17,'Novo Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715259,17,'Novo Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715507,17,'Oliveira de Fátima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715705,17,'Palmeirante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1715754,17,'Palmeirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716109,17,'Paraíso do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716208,17,'Paranã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716307,17,'Pau Darco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716505,17,'Pedro Afonso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716604,17,'Peixe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716653,17,'Pequizeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1716703,17,'Colméia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1717008,17,'Pindorama do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1717206,17,'Piraquê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1717503,17,'Pium');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1717800,17,'Ponte Alta do Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1717909,17,'Ponte Alta do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718006,17,'Porto Alegre do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718204,17,'Porto Nacional');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718303,17,'Praia Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718402,17,'Presidente Kennedy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718451,17,'Pugmil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718501,17,'Recursolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718550,17,'Riachinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718659,17,'Rio da Conceição');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718709,17,'Rio dos Bois');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718758,17,'Rio Sono');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718808,17,'Sampaio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718840,17,'Sandolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718865,17,'Santa Fé do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718881,17,'Santa Maria do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718899,17,'Santa Rita do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1718907,17,'Santa Rosa do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1719004,17,'Santa Tereza do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720002,17,'Santa Terezinha do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720101,17,'São Bento do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720150,17,'São Félix do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720200,17,'São Miguel do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720259,17,'São Salvador do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720309,17,'São Sebastião do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720499,17,'São Valério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720655,17,'Silvanópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720804,17,'Sítio Novo do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720853,17,'Sucupira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720903,17,'Taguatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720937,17,'Taipas do Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1720978,17,'Talismã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1721000,17,'Palmas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1721109,17,'Tocantínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1721208,17,'Tocantinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1721257,17,'Tupirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1721307,17,'Tupiratins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1722081,17,'Wanderlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(1722107,17,'Xambioá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100055,21,'Açailândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100105,21,'Afonso Cunha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100154,21,'Água doce do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100204,21,'Alcântara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100303,21,'Aldeias Altas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100402,21,'Altamira do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100436,21,'Alto Alegre do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100477,21,'Alto Alegre do Pindaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100501,21,'Alto Parnaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100550,21,'Amapá do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100600,21,'Amarante do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100709,21,'Anajatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100808,21,'Anapurus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100832,21,'Apicum-Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100873,21,'Araguanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100907,21,'Araioses');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2100956,21,'Arame');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101004,21,'Arari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101103,21,'Axixá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101202,21,'Bacabal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101251,21,'Bacabeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101301,21,'Bacuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101350,21,'Bacurituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101400,21,'Balsas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101509,21,'Barão de Grajaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101608,21,'Barra do Corda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101707,21,'Barreirinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101731,21,'Belágua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101772,21,'Bela Vista do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101806,21,'Benedito Leite');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101905,21,'Bequimão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101939,21,'Bernardo do Mearim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2101970,21,'Boa Vista do Gurupi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102002,21,'Bom Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102036,21,'Bom Jesus das Selvas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102077,21,'Bom Lugar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102101,21,'Brejo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102150,21,'Brejo de Areia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102200,21,'Buriti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102309,21,'Buriti Bravo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102325,21,'Buriticupu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102358,21,'Buritirana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102374,21,'Cachoeira Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102408,21,'Cajapió');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102507,21,'Cajari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102556,21,'Campestre do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102606,21,'Cândido Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102705,21,'Cantanhede');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102754,21,'Capinzal do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102804,21,'Carolina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2102903,21,'Carutapera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103000,21,'Caxias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103109,21,'Cedral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103125,21,'Central do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103158,21,'Centro do Guilherme');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103174,21,'Centro Novo do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103208,21,'Chapadinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103257,21,'Cidelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103307,21,'Codó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103406,21,'Coelho Neto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103505,21,'Colinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103554,21,'Conceição do Lago-Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103604,21,'Coroatá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103703,21,'Cururupu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103752,21,'davinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103802,21,'dom Pedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2103901,21,'Duque Bacelar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104008,21,'Esperantinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104057,21,'Estreito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104073,21,'Feira Nova do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104081,21,'Fernando Falcão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104099,21,'Formosa da Serra Negra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104107,21,'Fortaleza dos Nogueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104206,21,'Fortuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104305,21,'Godofredo Viana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104404,21,'Gonçalves Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104503,21,'Governador Archer');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104552,21,'Governador Edison Lobão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104602,21,'Governador Eugênio Barros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104628,21,'Governador Luiz Rocha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104651,21,'Governador Newton Bello');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104677,21,'Governador Nunes Freire');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104701,21,'Graça Aranha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104800,21,'Grajaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2104909,21,'Guimarães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105005,21,'Humberto de Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105104,21,'Icatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105153,21,'Igarapé do Meio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105203,21,'Igarapé Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105302,21,'Imperatriz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105351,21,'Itaipava do Grajaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105401,21,'Itapecuru Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105427,21,'Itinga do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105450,21,'Jatobá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105476,21,'Jenipapo dos Vieiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105500,21,'João Lisboa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105609,21,'Joselândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105658,21,'Junco do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105708,21,'Lago da Pedra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105807,21,'Lago do Junco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105906,21,'Lago Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105922,21,'Lagoa do Mato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105948,21,'Lago dos Rodrigues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105963,21,'Lagoa Grande do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2105989,21,'Lajeado Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106003,21,'Lima Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106102,21,'Loreto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106201,21,'Luís domingues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106300,21,'Magalhães de Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106326,21,'Maracaçumé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106359,21,'Marajá do Sena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106375,21,'Maranhãozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106409,21,'Mata Roma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106508,21,'Matinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106607,21,'Matões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106631,21,'Matões do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106672,21,'Milagres do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106706,21,'Mirador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106755,21,'Miranda do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106805,21,'Mirinzal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2106904,21,'Monção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107001,21,'Montes Altos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107100,21,'Morros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107209,21,'Nina Rodrigues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107258,21,'Nova Colinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107308,21,'Nova Iorque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107357,21,'Nova Olinda do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107407,21,'Olho Dágua das Cunhãs');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107456,21,'Olinda Nova do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107506,21,'Paço do Lumiar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107605,21,'Palmeirândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107704,21,'Paraibano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107803,21,'Parnarama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2107902,21,'Passagem Franca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108009,21,'Pastos Bons');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108058,21,'Paulino Neves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108108,21,'Paulo Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108207,21,'Pedreiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108256,21,'Pedro do Rosário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108306,21,'Penalva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108405,21,'Peri Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108454,21,'Peritoró');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108504,21,'Pindaré-Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108603,21,'Pinheiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108702,21,'Pio Xii');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108801,21,'Pirapemas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2108900,21,'Poção de Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109007,21,'Porto Franco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109056,21,'Porto Rico do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109106,21,'Presidente Dutra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109205,21,'Presidente Juscelino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109239,21,'Presidente Médici');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109270,21,'Presidente Sarney');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109304,21,'Presidente Vargas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109403,21,'Primeira Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109452,21,'Raposa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109502,21,'Riachão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109551,21,'Ribamar Fiquene');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109601,21,'Rosário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109700,21,'Sambaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109759,21,'Santa Filomena do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109809,21,'Santa Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2109908,21,'Santa Inês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110005,21,'Santa Luzia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110039,21,'Santa Luzia do Paruá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110104,21,'Santa Quitéria do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110203,21,'Santa Rita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110237,21,'Santana do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110278,21,'Santo Amaro do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110302,21,'Santo Antônio dos Lopes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110401,21,'São Benedito do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110500,21,'São Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110609,21,'São Bernardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110658,21,'São domingos do Azeitão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110708,21,'São domingos do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110807,21,'São Félix de Balsas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110856,21,'São Francisco do Brejão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2110906,21,'São Francisco do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111003,21,'São João Batista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111029,21,'São João do Carú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111052,21,'São João do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111078,21,'São João do Soter');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111102,21,'São João dos Patos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111201,21,'São José de Ribamar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111250,21,'São José dos Basílios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111300,21,'São Luís');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111409,21,'São Luís Gonzaga do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111508,21,'São Mateus do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111532,21,'São Pedro da Água Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111573,21,'São Pedro dos Crentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111607,21,'São Raimundo das Mangabeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111631,21,'São Raimundo do doca Bezerra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111672,21,'São Roberto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111706,21,'São Vicente Ferrer');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111722,21,'Satubinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111748,21,'Senador Alexandre Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111763,21,'Senador La Rocque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111789,21,'Serrano do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111805,21,'Sítio Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111904,21,'Sucupira do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2111953,21,'Sucupira do Riachão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112001,21,'Tasso Fragoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112100,21,'Timbiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112209,21,'Timon');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112233,21,'Trizidela do Vale');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112274,21,'Tufilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112308,21,'Tuntum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112407,21,'Turiaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112456,21,'Turilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112506,21,'Tutóia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112605,21,'Urbano Santos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112704,21,'Vargem Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112803,21,'Viana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112852,21,'Vila Nova dos Martírios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2112902,21,'Vitória do Mearim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2113009,21,'Vitorino Freire');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2114007,21,'Zé doca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200053,22,'Acauã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200103,22,'Agricolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200202,22,'Água Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200251,22,'Alagoinha do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200277,22,'Alegrete do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200301,22,'Alto Longá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200400,22,'Altos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200459,22,'Alvorada do Gurguéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200509,22,'Amarante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200608,22,'Angical do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200707,22,'Anísio de Abreu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200806,22,'Antônio Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200905,22,'Aroazes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2200954,22,'Aroeiras do Itaim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201002,22,'Arraial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201051,22,'Assunção do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201101,22,'Avelino Lopes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201150,22,'Baixa Grande do Ribeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201176,22,'Barra Dalcântara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201200,22,'Barras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201309,22,'Barreiras do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201408,22,'Barro Duro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201507,22,'Batalha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201556,22,'Bela Vista do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201572,22,'Belém do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201606,22,'Beneditinos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201705,22,'Bertolínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201739,22,'Betânia do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201770,22,'Boa Hora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201804,22,'Bocaina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201903,22,'Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201919,22,'Bom Princípio do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201929,22,'Bonfim do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201945,22,'Boqueirão do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201960,22,'Brasileira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2201988,22,'Brejo do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202000,22,'Buriti dos Lopes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202026,22,'Buriti dos Montes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202059,22,'Cabeceiras do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202075,22,'Cajazeiras do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202083,22,'Cajueiro da Praia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202091,22,'Caldeirão Grande do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202109,22,'Campinas do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202117,22,'Campo Alegre do Fidalgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202133,22,'Campo Grande do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202174,22,'Campo Largo do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202208,22,'Campo Maior');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202251,22,'Canavieira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202307,22,'Canto do Buriti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202406,22,'Capitão de Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202455,22,'Capitão Gervásio Oliveira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202505,22,'Caracol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202539,22,'Caraúbas do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202554,22,'Caridade do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202604,22,'Castelo do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202653,22,'Caxingó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202703,22,'Cocal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202711,22,'Cocal de Telha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202729,22,'Cocal dos Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202737,22,'Coivaras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202752,22,'Colônia do Gurguéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202778,22,'Colônia do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202802,22,'Conceição do Canindé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202851,22,'Coronel José Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2202901,22,'Corrente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203008,22,'Cristalândia do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203107,22,'Cristino Castro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203206,22,'Curimatá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203230,22,'Currais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203255,22,'Curralinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203271,22,'Curral Novo do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203305,22,'demerval Lobão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203354,22,'Dirceu Arcoverde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203404,22,'dom Expedito Lopes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203420,22,'domingos Mourão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203453,22,'dom Inocêncio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203503,22,'Elesbão Veloso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203602,22,'Eliseu Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203701,22,'Esperantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203750,22,'Fartura do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203800,22,'Flores do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203859,22,'Floresta do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2203909,22,'Floriano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204006,22,'Francinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204105,22,'Francisco Ayres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204154,22,'Francisco Macedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204204,22,'Francisco Santos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204303,22,'Fronteiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204352,22,'Geminiano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204402,22,'Gilbués');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204501,22,'Guadalupe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204550,22,'Guaribas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204600,22,'Hugo Napoleão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204659,22,'Ilha Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204709,22,'Inhuma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204808,22,'Ipiranga do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2204907,22,'Isaías Coelho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205003,22,'Itainópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205102,22,'Itaueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205151,22,'Jacobina do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205201,22,'Jaicós');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205250,22,'Jardim do Mulato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205276,22,'Jatobá do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205300,22,'Jerumenha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205359,22,'João Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205409,22,'Joaquim Pires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205458,22,'Joca Marques');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205508,22,'José de Freitas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205516,22,'Juazeiro do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205524,22,'Júlio Borges');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205532,22,'Jurema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205540,22,'Lagoinha do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205557,22,'Lagoa Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205565,22,'Lagoa do Barro do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205573,22,'Lagoa de São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205581,22,'Lagoa do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205599,22,'Lagoa do Sítio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205607,22,'Landri Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205706,22,'Luís Correia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205805,22,'Luzilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205854,22,'Madeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205904,22,'Manoel Emídio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2205953,22,'Marcolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206001,22,'Marcos Parente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206050,22,'Massapê do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206100,22,'Matias Olímpio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206209,22,'Miguel Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206308,22,'Miguel Leão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206357,22,'Milton Brandão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206407,22,'Monsenhor Gil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206506,22,'Monsenhor Hipólito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206605,22,'Monte Alegre do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206654,22,'Morro Cabeça No Tempo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206670,22,'Morro do Chapéu do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206696,22,'Murici dos Portelas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206704,22,'Nazaré do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206720,22,'Nazária');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206753,22,'Nossa Senhora de Nazaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206803,22,'Nossa Senhora dos Remédios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206902,22,'Novo Oriente do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2206951,22,'Novo Santo Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207009,22,'Oeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207108,22,'Olho Dágua do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207207,22,'Padre Marcos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207306,22,'Paes Landim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207355,22,'Pajeú do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207405,22,'Palmeira do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207504,22,'Palmeirais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207553,22,'Paquetá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207603,22,'Parnaguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207702,22,'Parnaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207751,22,'Passagem Franca do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207777,22,'Patos do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207793,22,'Pau Darco do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207801,22,'Paulistana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207850,22,'Pavussu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207900,22,'Pedro Ii');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207934,22,'Pedro Laurentino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2207959,22,'Nova Santa Rita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208007,22,'Picos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208106,22,'Pimenteiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208205,22,'Pio Ix');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208304,22,'Piracuruca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208403,22,'Piripiri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208502,22,'Porto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208551,22,'Porto Alegre do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208601,22,'Prata do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208650,22,'Queimada Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208700,22,'Redenção do Gurguéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208809,22,'Regeneração');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208858,22,'Riacho Frio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208874,22,'Ribeira do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2208908,22,'Ribeiro Gonçalves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209005,22,'Rio Grande do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209104,22,'Santa Cruz do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209153,22,'Santa Cruz dos Milagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209203,22,'Santa Filomena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209302,22,'Santa Luz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209351,22,'Santana do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209377,22,'Santa Rosa do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209401,22,'Santo Antônio de Lisboa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209450,22,'Santo Antônio dos Milagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209500,22,'Santo Inácio do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209559,22,'São Braz do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209609,22,'São Félix do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209658,22,'São Francisco de Assis do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209708,22,'São Francisco do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209757,22,'São Gonçalo do Gurguéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209807,22,'São Gonçalo do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209856,22,'São João da Canabrava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209872,22,'São João da Fronteira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209906,22,'São João da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209955,22,'São João da Varjota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2209971,22,'São João do Arraial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210003,22,'São João do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210052,22,'São José do Divino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210102,22,'São José do Peixe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210201,22,'São José do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210300,22,'São Julião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210359,22,'São Lourenço do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210375,22,'São Luis do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210383,22,'São Miguel da Baixa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210391,22,'São Miguel do Fidalgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210409,22,'São Miguel do Tapuio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210508,22,'São Pedro do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210607,22,'São Raimundo Nonato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210623,22,'Sebastião Barros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210631,22,'Sebastião Leal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210656,22,'Sigefredo Pacheco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210706,22,'Simões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210805,22,'Simplício Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210904,22,'Socorro do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210938,22,'Sussuapara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210953,22,'Tamboril do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2210979,22,'Tanque do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211001,22,'Teresina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211100,22,'União');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211209,22,'Uruçuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211308,22,'Valença do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211357,22,'Várzea Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211407,22,'Várzea Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211506,22,'Vera Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211605,22,'Vila Nova do Piauí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2211704,22,'Wall Ferraz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300101,23,'Abaiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300150,23,'Acarape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300200,23,'Acaraú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300309,23,'Acopiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300408,23,'Aiuaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300507,23,'Alcântaras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300606,23,'Altaneira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300705,23,'Alto Santo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300754,23,'Amontada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300804,23,'Antonina do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2300903,23,'Apuiarés');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301000,23,'Aquiraz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301109,23,'Aracati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301208,23,'Aracoiaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301257,23,'Ararendá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301307,23,'Araripe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301406,23,'Aratuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301505,23,'Arneiroz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301604,23,'Assaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301703,23,'Aurora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301802,23,'Baixio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301851,23,'Banabuiú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301901,23,'Barbalha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2301950,23,'Barreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302008,23,'Barro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302057,23,'Barroquinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302107,23,'Baturité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302206,23,'Beberibe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302305,23,'Bela Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302404,23,'Boa Viagem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302503,23,'Brejo Santo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302602,23,'Camocim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302701,23,'Campos Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302800,23,'Canindé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2302909,23,'Capistrano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303006,23,'Caridade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303105,23,'Cariré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303204,23,'Caririaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303303,23,'Cariús');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303402,23,'Carnaubal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303501,23,'Cascavel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303600,23,'Catarina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303659,23,'Catunda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303709,23,'Caucaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303808,23,'Cedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303907,23,'Chaval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303931,23,'Choró');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2303956,23,'Chorozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304004,23,'Coreaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304103,23,'Crateús');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304202,23,'Crato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304236,23,'Croatá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304251,23,'Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304269,23,'deputado Irapuan Pinheiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304277,23,'Ererê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304285,23,'Eusébio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304301,23,'Farias Brito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304350,23,'Forquilha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304400,23,'Fortaleza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304459,23,'Fortim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304509,23,'Frecheirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304608,23,'General Sampaio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304657,23,'Graça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304707,23,'Granja');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304806,23,'Granjeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304905,23,'Groaíras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2304954,23,'Guaiúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305001,23,'Guaraciaba do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305100,23,'Guaramiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305209,23,'Hidrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305233,23,'Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305266,23,'Ibaretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305308,23,'Ibiapina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305332,23,'Ibicuitinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305357,23,'Icapuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305407,23,'Icó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305506,23,'Iguatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305605,23,'Independência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305654,23,'Ipaporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305704,23,'Ipaumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305803,23,'Ipu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2305902,23,'Ipueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306009,23,'Iracema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306108,23,'Irauçuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306207,23,'Itaiçaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306256,23,'Itaitinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306306,23,'Itapajé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306405,23,'Itapipoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306504,23,'Itapiúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306553,23,'Itarema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306603,23,'Itatira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306702,23,'Jaguaretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306801,23,'Jaguaribara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2306900,23,'Jaguaribe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307007,23,'Jaguaruana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307106,23,'Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307205,23,'Jati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307254,23,'Jijoca de Jericoacoara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307304,23,'Juazeiro do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307403,23,'Jucás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307502,23,'Lavras da Mangabeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307601,23,'Limoeiro do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307635,23,'Madalena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307650,23,'Maracanaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307700,23,'Maranguape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307809,23,'Marco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2307908,23,'Martinópole');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308005,23,'Massapê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308104,23,'Mauriti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308203,23,'Meruoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308302,23,'Milagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308351,23,'Milhã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308377,23,'Miraíma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308401,23,'Missão Velha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308500,23,'Mombaça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308609,23,'Monsenhor Tabosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308708,23,'Morada Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308807,23,'Moraújo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2308906,23,'Morrinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309003,23,'Mucambo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309102,23,'Mulungu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309201,23,'Nova Olinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309300,23,'Nova Russas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309409,23,'Novo Oriente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309458,23,'Ocara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309508,23,'Orós');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309607,23,'Pacajus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309706,23,'Pacatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309805,23,'Pacoti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2309904,23,'Pacujá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310001,23,'Palhano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310100,23,'Palmácia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310209,23,'Paracuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310258,23,'Paraipaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310308,23,'Parambu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310407,23,'Paramoti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310506,23,'Pedra Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310605,23,'Penaforte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310704,23,'Pentecoste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310803,23,'Pereiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310852,23,'Pindoretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310902,23,'Piquet Carneiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2310951,23,'Pires Ferreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311009,23,'Poranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311108,23,'Porteiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311207,23,'Potengi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311231,23,'Potiretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311264,23,'Quiterianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311306,23,'Quixadá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311355,23,'Quixelô');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311405,23,'Quixeramobim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311504,23,'Quixeré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311603,23,'Redenção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311702,23,'Reriutaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311801,23,'Russas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311900,23,'Saboeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2311959,23,'Salitre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312007,23,'Santana do Acaraú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312106,23,'Santana do Cariri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312205,23,'Santa Quitéria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312304,23,'São Benedito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312403,23,'São Gonçalo do Amarante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312502,23,'São João do Jaguaribe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312601,23,'São Luís do Curu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312700,23,'Senador Pompeu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312809,23,'Senador Sá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2312908,23,'Sobral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313005,23,'Solonópole');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313104,23,'Tabuleiro do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313203,23,'Tamboril');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313252,23,'Tarrafas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313302,23,'Tauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313351,23,'Tejuçuoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313401,23,'Tianguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313500,23,'Trairi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313559,23,'Tururu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313609,23,'Ubajara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313708,23,'Umari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313757,23,'Umirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313807,23,'Uruburetama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313906,23,'Uruoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2313955,23,'Varjota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2314003,23,'Várzea Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2314102,23,'Viçosa do Ceará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400109,24,'Acari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400208,24,'Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400307,24,'Afonso Bezerra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400406,24,'Água Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400505,24,'Alexandria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400604,24,'Almino Afonso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400703,24,'Alto do Rodrigues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400802,24,'Angicos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2400901,24,'Antônio Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401008,24,'Apodi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401107,24,'Areia Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401206,24,'Arês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401305,24,'Augusto Severo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401404,24,'Baía Formosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401453,24,'Baraúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401503,24,'Barcelona');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401602,24,'Bento Fernandes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401651,24,'Bodó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401701,24,'Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401800,24,'Brejinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401859,24,'Caiçara do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2401909,24,'Caiçara do Rio do Vento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402006,24,'Caicó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402105,24,'Campo Redondo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402204,24,'Canguaretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402303,24,'Caraúbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402402,24,'Carnaúba dos dantas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402501,24,'Carnaubais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402600,24,'Ceará-Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402709,24,'Cerro Corá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402808,24,'Coronel Ezequiel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2402907,24,'Coronel João Pessoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403004,24,'Cruzeta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403103,24,'Currais Novos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403202,24,'doutor Severiano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403251,24,'Parnamirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403301,24,'Encanto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403400,24,'Equador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403509,24,'Espírito Santo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403608,24,'Extremoz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403707,24,'Felipe Guerra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403756,24,'Fernando Pedroza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403806,24,'Florânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2403905,24,'Francisco dantas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404002,24,'Frutuoso Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404101,24,'Galinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404200,24,'Goianinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404309,24,'Governador Dix-Sept Rosado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404408,24,'Grossos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404507,24,'Guamaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404606,24,'Ielmo Marinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404705,24,'Ipanguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404804,24,'Ipueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404853,24,'Itajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2404903,24,'Itaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405009,24,'Jaçanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405108,24,'Jandaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405207,24,'Janduís');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405306,24,'Januário Cicco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405405,24,'Japi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405504,24,'Jardim de Angicos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405603,24,'Jardim de Piranhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405702,24,'Jardim do Seridó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405801,24,'João Câmara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2405900,24,'João Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406007,24,'José da Penha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406106,24,'Jucurutu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406155,24,'Jundiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406205,24,'Lagoa Danta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406304,24,'Lagoa de Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406403,24,'Lagoa de Velhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406502,24,'Lagoa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406601,24,'Lagoa Salgada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406700,24,'Lajes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406809,24,'Lajes Pintadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2406908,24,'Lucrécia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407005,24,'Luís Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407104,24,'Macaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407203,24,'Macau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407252,24,'Major Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407302,24,'Marcelino Vieira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407401,24,'Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407500,24,'Maxaranguape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407609,24,'Messias Targino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407708,24,'Montanhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407807,24,'Monte Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2407906,24,'Monte das Gameleiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408003,24,'Mossoró');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408102,24,'Natal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408201,24,'Nísia Floresta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408300,24,'Nova Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408409,24,'Olho-Dágua do Borges');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408508,24,'Ouro Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408607,24,'Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408706,24,'Paraú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408805,24,'Parazinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408904,24,'Parelhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2408953,24,'Rio do Fogo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409100,24,'Passa E Fica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409209,24,'Passagem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409308,24,'Patu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409332,24,'Santa Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409407,24,'Pau dos Ferros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409506,24,'Pedra Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409605,24,'Pedra Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409704,24,'Pedro Avelino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409803,24,'Pedro Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2409902,24,'Pendências');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410009,24,'Pilões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410108,24,'Poço Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410207,24,'Portalegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410256,24,'Porto do Mangue');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410306,24,'Serra Caiada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410405,24,'Pureza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410504,24,'Rafael Fernandes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410603,24,'Rafael Godeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410702,24,'Riacho da Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410801,24,'Riacho de Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2410900,24,'Riachuelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411007,24,'Rodolfo Fernandes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411056,24,'Tibau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411106,24,'Ruy Barbosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411205,24,'Santa Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411403,24,'Santana do Matos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411429,24,'Santana do Seridó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411502,24,'Santo Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411601,24,'São Bento do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411700,24,'São Bento do Trairí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411809,24,'São Fernando');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2411908,24,'São Francisco do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412005,24,'São Gonçalo do Amarante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412104,24,'São João do Sabugi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412203,24,'São José de Mipibu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412302,24,'São José do Campestre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412401,24,'São José do Seridó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412500,24,'São Miguel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412559,24,'São Miguel do Gostoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412609,24,'São Paulo do Potengi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412708,24,'São Pedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412807,24,'São Rafael');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2412906,24,'São Tomé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413003,24,'São Vicente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413102,24,'Senador Elói de Souza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413201,24,'Senador Georgino Avelino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413300,24,'Serra de São Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413359,24,'Serra do Mel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413409,24,'Serra Negra do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413508,24,'Serrinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413557,24,'Serrinha dos Pintos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413607,24,'Severiano Melo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413706,24,'Sítio Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413805,24,'Taboleiro Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2413904,24,'Taipu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414001,24,'Tangará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414100,24,'Tenente Ananias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414159,24,'Tenente Laurentino Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414209,24,'Tibau do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414308,24,'Timbaúba dos Batistas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414407,24,'Touros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414456,24,'Triunfo Potiguar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414506,24,'Umarizal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414605,24,'Upanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414704,24,'Várzea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414753,24,'Venha-Ver');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414803,24,'Vera Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2414902,24,'Viçosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2415008,24,'Vila Flor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500106,25,'Água Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500205,25,'Aguiar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500304,25,'Alagoa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500403,25,'Alagoa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500502,25,'Alagoinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500536,25,'Alcantil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500577,25,'Algodão de Jandaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500601,25,'Alhandra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500700,25,'São João do Rio do Peixe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500734,25,'Amparo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500775,25,'Aparecida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500809,25,'Araçagi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2500908,25,'Arara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501005,25,'Araruna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501104,25,'Areia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501153,25,'Areia de Baraúnas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501203,25,'Areial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501302,25,'Aroeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501351,25,'Assunção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501401,25,'Baía da Traição');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501500,25,'Bananeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501534,25,'Baraúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501575,25,'Barra de Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501609,25,'Barra de Santa Rosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501708,25,'Barra de São Miguel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501807,25,'Bayeux');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2501906,25,'Belém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502003,25,'Belém do Brejo do Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502052,25,'Bernardino Batista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502102,25,'Boa Ventura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502151,25,'Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502201,25,'Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502300,25,'Bom Sucesso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502409,25,'Bonito de Santa Fé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502508,25,'Boqueirão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502607,25,'Igaracy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502706,25,'Borborema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502805,25,'Brejo do Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2502904,25,'Brejo dos Santos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503001,25,'Caaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503100,25,'Cabaceiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503209,25,'Cabedelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503308,25,'Cachoeira dos Índios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503407,25,'Cacimba de Areia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503506,25,'Cacimba de dentro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503555,25,'Cacimbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503605,25,'Caiçara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503704,25,'Cajazeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503753,25,'Cajazeirinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503803,25,'Caldas Brandão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2503902,25,'Camalaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504009,25,'Campina Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504033,25,'Capim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504074,25,'Caraúbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504108,25,'Carrapateira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504157,25,'Casserengue');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504207,25,'Catingueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504306,25,'Catolé do Rocha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504355,25,'Caturité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504405,25,'Conceição');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504504,25,'Condado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504603,25,'Conde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504702,25,'Congo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504801,25,'Coremas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504850,25,'Coxixola');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2504900,25,'Cruz do Espírito Santo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505006,25,'Cubati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505105,25,'Cuité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505204,25,'Cuitegi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505238,25,'Cuité de Mamanguape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505279,25,'Curral de Cima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505303,25,'Curral Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505352,25,'damião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505402,25,'desterro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505501,25,'Vista Serrana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505600,25,'Diamante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505709,25,'dona Inês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505808,25,'Duas Estradas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2505907,25,'Emas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506004,25,'Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506103,25,'Fagundes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506202,25,'Frei Martinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506251,25,'Gado Bravo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506301,25,'Guarabira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506400,25,'Gurinhém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506509,25,'Gurjão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506608,25,'Ibiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506707,25,'Imaculada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506806,25,'Ingá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2506905,25,'Itabaiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507002,25,'Itaporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507101,25,'Itapororoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507200,25,'Itatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507309,25,'Jacaraú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507408,25,'Jericó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507507,25,'João Pessoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507606,25,'Juarez Távora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507705,25,'Juazeirinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507804,25,'Junco do Seridó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2507903,25,'Juripiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508000,25,'Juru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508109,25,'Lagoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508208,25,'Lagoa de dentro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508307,25,'Lagoa Seca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508406,25,'Lastro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508505,25,'Livramento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508554,25,'Logradouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508604,25,'Lucena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508703,25,'Mãe Dágua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508802,25,'Malta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2508901,25,'Mamanguape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509008,25,'Manaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509057,25,'Marcação');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509107,25,'Mari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509156,25,'Marizópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509206,25,'Massaranduba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509305,25,'Mataraca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509339,25,'Matinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509370,25,'Mato Grosso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509396,25,'Maturéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509404,25,'Mogeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509503,25,'Montadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509602,25,'Monte Horebe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509701,25,'Monteiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509800,25,'Mulungu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2509909,25,'Natuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510006,25,'Nazarezinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510105,25,'Nova Floresta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510204,25,'Nova Olinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510303,25,'Nova Palmeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510402,25,'Olho Dágua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510501,25,'Olivedos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510600,25,'Ouro Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510659,25,'Parari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510709,25,'Passagem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510808,25,'Patos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2510907,25,'Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511004,25,'Pedra Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511103,25,'Pedra Lavrada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511202,25,'Pedras de Fogo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511301,25,'Piancó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511400,25,'Picuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511509,25,'Pilar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511608,25,'Pilões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511707,25,'Pilõezinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511806,25,'Pirpirituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2511905,25,'Pitimbu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512002,25,'Pocinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512036,25,'Poço dantas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512077,25,'Poço de José de Moura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512101,25,'Pombal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512200,25,'Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512309,25,'Princesa Isabel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512408,25,'Puxinanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512507,25,'Queimadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512606,25,'Quixaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512705,25,'Remígio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512721,25,'Pedro Régis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512747,25,'Riachão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512754,25,'Riachão do Bacamarte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512762,25,'Riachão do Poço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512788,25,'Riacho de Santo Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512804,25,'Riacho dos Cavalos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2512903,25,'Rio Tinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513000,25,'Salgadinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513109,25,'Salgado de São Félix');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513158,25,'Santa Cecília');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513208,25,'Santa Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513307,25,'Santa Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513356,25,'Santa Inês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513406,25,'Santa Luzia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513505,25,'Santana de Mangueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513604,25,'Santana dos Garrotes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513653,25,'Joca Claudino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513703,25,'Santa Rita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513802,25,'Santa Teresinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513851,25,'Santo André');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513901,25,'São Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513927,25,'São Bentinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513943,25,'São domingos do Cariri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513968,25,'São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2513984,25,'São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514008,25,'São João do Cariri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514107,25,'São João do Tigre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514206,25,'São José da Lagoa Tapada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514305,25,'São José de Caiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514404,25,'São José de Espinharas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514453,25,'São José dos Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514503,25,'São José de Piranhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514552,25,'São José de Princesa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514602,25,'São José do Bonfim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514651,25,'São José do Brejo do Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514701,25,'São José do Sabugi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514800,25,'São José dos Cordeiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2514909,25,'São Mamede');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515005,25,'São Miguel de Taipu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515104,25,'São Sebastião de Lagoa de Roça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515203,25,'São Sebastião do Umbuzeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515302,25,'Sapé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515401,25,'São Vicente do Seridó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515500,25,'Serra Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515609,25,'Serra da Raiz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515708,25,'Serra Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515807,25,'Serra Redonda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515906,25,'Serraria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515930,25,'Sertãozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2515971,25,'Sobrado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516003,25,'Solânea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516102,25,'Soledade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516151,25,'Sossêgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516201,25,'Sousa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516300,25,'Sumé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516409,25,'Tacima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516508,25,'Taperoá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516607,25,'Tavares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516706,25,'Teixeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516755,25,'Tenório');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516805,25,'Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2516904,25,'Uiraúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2517001,25,'Umbuzeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2517100,25,'Várzea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2517209,25,'Vieirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2517407,25,'Zabelê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600054,26,'Abreu E Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600104,26,'Afogados da Ingazeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600203,26,'Afrânio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600302,26,'Agrestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600401,26,'Água Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600500,26,'Águas Belas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600609,26,'Alagoinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600708,26,'Aliança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600807,26,'Altinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2600906,26,'Amaraji');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601003,26,'Angelim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601052,26,'Araçoiaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601102,26,'Araripina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601201,26,'Arcoverde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601300,26,'Barra de Guabiraba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601409,26,'Barreiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601508,26,'Belém de Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601607,26,'Belém do São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601706,26,'Belo Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601805,26,'Betânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2601904,26,'Bezerros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602001,26,'Bodocó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602100,26,'Bom Conselho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602209,26,'Bom Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602308,26,'Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602407,26,'Brejão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602506,26,'Brejinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602605,26,'Brejo da Madre de deus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602704,26,'Buenos Aires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602803,26,'Buíque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2602902,26,'Cabo de Santo Agostinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603009,26,'Cabrobó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603108,26,'Cachoeirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603207,26,'Caetés');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603306,26,'Calçado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603405,26,'Calumbi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603454,26,'Camaragibe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603504,26,'Camocim de São Félix');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603603,26,'Camutanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603702,26,'Canhotinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603801,26,'Capoeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603900,26,'Carnaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2603926,26,'Carnaubeira da Penha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604007,26,'Carpina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604106,26,'Caruaru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604155,26,'Casinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604205,26,'Catende');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604304,26,'Cedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604403,26,'Chã de Alegria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604502,26,'Chã Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604601,26,'Condado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604700,26,'Correntes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604809,26,'Cortês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2604908,26,'Cumaru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605004,26,'Cupira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605103,26,'Custódia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605152,26,'dormentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605202,26,'Escada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605301,26,'Exu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605400,26,'Feira Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605459,26,'Fernando de Noronha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605509,26,'Ferreiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605608,26,'Flores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605707,26,'Floresta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605806,26,'Frei Miguelinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2605905,26,'Gameleira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606002,26,'Garanhuns');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606101,26,'Glória do Goitá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606200,26,'Goiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606309,26,'Granito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606408,26,'Gravatá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606507,26,'Iati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606606,26,'Ibimirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606705,26,'Ibirajuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606804,26,'Igarassu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2606903,26,'Iguaracy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607000,26,'Inajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607109,26,'Ingazeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607208,26,'Ipojuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607307,26,'Ipubi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607406,26,'Itacuruba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607505,26,'Itaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607604,26,'Ilha de Itamaracá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607653,26,'Itambé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607703,26,'Itapetim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607752,26,'Itapissuma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607802,26,'Itaquitinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607901,26,'Jaboatão dos Guararapes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2607950,26,'Jaqueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608008,26,'Jataúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608057,26,'Jatobá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608107,26,'João Alfredo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608206,26,'Joaquim Nabuco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608255,26,'Jucati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608305,26,'Jupi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608404,26,'Jurema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608453,26,'Lagoa do Carro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608503,26,'Lagoa de Itaenga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608602,26,'Lagoa do Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608701,26,'Lagoa dos Gatos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608750,26,'Lagoa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608800,26,'Lajedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2608909,26,'Limoeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609006,26,'Macaparana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609105,26,'Machados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609154,26,'Manari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609204,26,'Maraial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609303,26,'Mirandiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609402,26,'Moreno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609501,26,'Nazaré da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609600,26,'Olinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609709,26,'Orobó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609808,26,'Orocó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2609907,26,'Ouricuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610004,26,'Palmares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610103,26,'Palmeirina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610202,26,'Panelas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610301,26,'Paranatama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610400,26,'Parnamirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610509,26,'Passira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610608,26,'Paudalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610707,26,'Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610806,26,'Pedra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2610905,26,'Pesqueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611002,26,'Petrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611101,26,'Petrolina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611200,26,'Poção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611309,26,'Pombos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611408,26,'Primavera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611507,26,'Quipapá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611533,26,'Quixaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611606,26,'Recife');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611705,26,'Riacho das Almas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611804,26,'Ribeirão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2611903,26,'Rio Formoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612000,26,'Sairé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612109,26,'Salgadinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612208,26,'Salgueiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612307,26,'Saloá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612406,26,'Sanharó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612455,26,'Santa Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612471,26,'Santa Cruz da Baixa Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612505,26,'Santa Cruz do Capibaribe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612554,26,'Santa Filomena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612604,26,'Santa Maria da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612703,26,'Santa Maria do Cambucá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612802,26,'Santa Terezinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2612901,26,'São Benedito do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613008,26,'São Bento do Una');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613107,26,'São Caitano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613206,26,'São João');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613305,26,'São Joaquim do Monte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613404,26,'São José da Coroa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613503,26,'São José do Belmonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613602,26,'São José do Egito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613701,26,'São Lourenço da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613800,26,'São Vicente Ferrer');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2613909,26,'Serra Talhada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614006,26,'Serrita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614105,26,'Sertânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614204,26,'Sirinhaém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614303,26,'Moreilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614402,26,'Solidão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614501,26,'Surubim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614600,26,'Tabira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614709,26,'Tacaimbó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614808,26,'Tacaratu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2614857,26,'Tamandaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615003,26,'Taquaritinga do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615102,26,'Terezinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615201,26,'Terra Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615300,26,'Timbaúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615409,26,'Toritama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615508,26,'Tracunhaém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615607,26,'Trindade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615706,26,'Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615805,26,'Tupanatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2615904,26,'Tuparetama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616001,26,'Venturosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616100,26,'Verdejante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616183,26,'Vertente do Lério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616209,26,'Vertentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616308,26,'Vicência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616407,26,'Vitória de Santo Antão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2616506,26,'Xexéu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700102,27,'Água Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700201,27,'Anadia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700300,27,'Arapiraca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700409,27,'Atalaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700508,27,'Barra de Santo Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700607,27,'Barra de São Miguel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700706,27,'Batalha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700805,27,'Belém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2700904,27,'Belo Monte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701001,27,'Boca da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701100,27,'Branquinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701209,27,'Cacimbinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701308,27,'Cajueiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701357,27,'Campestre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701407,27,'Campo Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701506,27,'Campo Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701605,27,'Canapi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701704,27,'Capela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701803,27,'Carneiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2701902,27,'Chã Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702009,27,'Coité do Nóia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702108,27,'Colônia Leopoldina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702207,27,'Coqueiro Seco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702306,27,'Coruripe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702355,27,'Craíbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702405,27,'delmiro Gouveia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702504,27,'dois Riachos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702553,27,'Estrela de Alagoas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702603,27,'Feira Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702702,27,'Feliz deserto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702801,27,'Flexeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2702900,27,'Girau do Ponciano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703007,27,'Ibateguara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703106,27,'Igaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703205,27,'Igreja Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703304,27,'Inhapi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703403,27,'Jacaré dos Homens');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703502,27,'Jacuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703601,27,'Japaratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703700,27,'Jaramataia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703759,27,'Jequiá da Praia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703809,27,'Joaquim Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2703908,27,'Jundiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704005,27,'Junqueiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704104,27,'Lagoa da Canoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704203,27,'Limoeiro de Anadia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704302,27,'Maceió');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704401,27,'Major Isidoro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704500,27,'Maragogi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704609,27,'Maravilha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704708,27,'Marechal deodoro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704807,27,'Maribondo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2704906,27,'Mar Vermelho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705002,27,'Mata Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705101,27,'Matriz de Camaragibe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705200,27,'Messias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705309,27,'Minador do Negrão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705408,27,'Monteirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705507,27,'Murici');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705606,27,'Novo Lino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705705,27,'Olho Dágua das Flores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705804,27,'Olho Dágua do Casado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2705903,27,'Olho Dágua Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706000,27,'Olivença');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706109,27,'Ouro Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706208,27,'Palestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706307,27,'Palmeira dos Índios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706406,27,'Pão de Açúcar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706422,27,'Pariconha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706448,27,'Paripueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706505,27,'Passo de Camaragibe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706604,27,'Paulo Jacinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706703,27,'Penedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706802,27,'Piaçabuçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2706901,27,'Pilar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707008,27,'Pindoba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707107,27,'Piranhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707206,27,'Poço das Trincheiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707305,27,'Porto Calvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707404,27,'Porto de Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707503,27,'Porto Real do Colégio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707602,27,'Quebrangulo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707701,27,'Rio Largo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707800,27,'Roteiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2707909,27,'Santa Luzia do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708006,27,'Santana do Ipanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708105,27,'Santana do Mundaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708204,27,'São Brás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708303,27,'São José da Laje');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708402,27,'São José da Tapera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708501,27,'São Luís do Quitunde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708600,27,'São Miguel dos Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708709,27,'São Miguel dos Milagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708808,27,'São Sebastião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708907,27,'Satuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2708956,27,'Senador Rui Palmeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709004,27,'Tanque Darca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709103,27,'Taquarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709152,27,'Teotônio Vilela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709202,27,'Traipu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709301,27,'União dos Palmares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2709400,27,'Viçosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800100,28,'Amparo de São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800209,28,'Aquidabã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800308,28,'Aracaju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800407,28,'Arauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800506,28,'Areia Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800605,28,'Barra dos Coqueiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800670,28,'Boquim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2800704,28,'Brejo Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801009,28,'Campo do Brito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801108,28,'Canhoba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801207,28,'Canindé de São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801306,28,'Capela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801405,28,'Carira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801504,28,'Carmópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801603,28,'Cedro de São João');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801702,28,'Cristinápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2801900,28,'Cumbe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802007,28,'Divina Pastora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802106,28,'Estância');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802205,28,'Feira Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802304,28,'Frei Paulo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802403,28,'Gararu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802502,28,'General Maynard');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802601,28,'Gracho Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802700,28,'Ilha das Flores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802809,28,'Indiaroba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2802908,28,'Itabaiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803005,28,'Itabaianinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803104,28,'Itabi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803203,28,'Itaporanga Dajuda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803302,28,'Japaratuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803401,28,'Japoatã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803500,28,'Lagarto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803609,28,'Laranjeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803708,28,'Macambira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803807,28,'Malhada dos Bois');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2803906,28,'Malhador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804003,28,'Maruim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804102,28,'Moita Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804201,28,'Monte Alegre de Sergipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804300,28,'Muribeca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804409,28,'Neópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804458,28,'Nossa Senhora Aparecida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804508,28,'Nossa Senhora da Glória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804607,28,'Nossa Senhora das dores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804706,28,'Nossa Senhora de Lourdes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804805,28,'Nossa Senhora do Socorro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2804904,28,'Pacatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805000,28,'Pedra Mole');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805109,28,'Pedrinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805208,28,'Pinhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805307,28,'Pirambu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805406,28,'Poço Redondo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805505,28,'Poço Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805604,28,'Porto da Folha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805703,28,'Propriá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805802,28,'Riachão do dantas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2805901,28,'Riachuelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806008,28,'Ribeirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806107,28,'Rosário do Catete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806206,28,'Salgado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806305,28,'Santa Luzia do Itanhy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806404,28,'Santana do São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806503,28,'Santa Rosa de Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806602,28,'Santo Amaro das Brotas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806701,28,'São Cristóvão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806800,28,'São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2806909,28,'São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807006,28,'São Miguel do Aleixo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807105,28,'Simão Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807204,28,'Siriri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807303,28,'Telha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807402,28,'Tobias Barreto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807501,28,'Tomar do Geru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2807600,28,'Umbaúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900108,29,'Abaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900207,29,'Abaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900306,29,'Acajutiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900355,29,'Adustina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900405,29,'Água Fria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900504,29,'Érico Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900603,29,'Aiquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900702,29,'Alagoinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900801,29,'Alcobaça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2900900,29,'Almadina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901007,29,'Amargosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901106,29,'Amélia Rodrigues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901155,29,'América dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901205,29,'Anagé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901304,29,'Andaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901353,29,'Andorinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901403,29,'Angical');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901502,29,'Anguera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901601,29,'Antas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901700,29,'Antônio Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901809,29,'Antônio Gonçalves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901908,29,'Aporá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2901957,29,'Apuarema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902005,29,'Aracatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902054,29,'Araças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902104,29,'Araci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902203,29,'Aramari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902252,29,'Arataca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902302,29,'Aratuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902401,29,'Aurelino Leal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902500,29,'Baianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902609,29,'Baixa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902658,29,'Banzaê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902708,29,'Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902807,29,'Barra da Estiva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2902906,29,'Barra do Choça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903003,29,'Barra do Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903102,29,'Barra do Rocha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903201,29,'Barreiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903235,29,'Barro Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903276,29,'Barrocas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903300,29,'Barro Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903409,29,'Belmonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903508,29,'Belo Campo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903607,29,'Biritinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903706,29,'Boa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903805,29,'Boa Vista do Tupim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903904,29,'Bom Jesus da Lapa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2903953,29,'Bom Jesus da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904001,29,'Boninal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904050,29,'Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904100,29,'Boquira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904209,29,'Botuporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904308,29,'Brejões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904407,29,'Brejolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904506,29,'Brotas de Macaúbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904605,29,'Brumado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904704,29,'Buerarema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904753,29,'Buritirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904803,29,'Caatiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904852,29,'Cabaceiras do Paraguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2904902,29,'Cachoeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905008,29,'Caculé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905107,29,'Caém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905156,29,'Caetanos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905206,29,'Caetité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905305,29,'Cafarnaum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905404,29,'Cairu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905503,29,'Caldeirão Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905602,29,'Camacan');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905701,29,'Camaçari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905800,29,'Camamu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2905909,29,'Campo Alegre de Lourdes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906006,29,'Campo Formoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906105,29,'Canápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906204,29,'Canarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906303,29,'Canavieiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906402,29,'Candeal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906501,29,'Candeias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906600,29,'Candiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906709,29,'Cândido Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906808,29,'Cansanção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906824,29,'Canudos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906857,29,'Capela do Alto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906873,29,'Capim Grosso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906899,29,'Caraíbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2906907,29,'Caravelas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907004,29,'Cardeal da Silva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907103,29,'Carinhanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907202,29,'Casa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907301,29,'Castro Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907400,29,'Catolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907509,29,'Catu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907558,29,'Caturama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907608,29,'Central');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907707,29,'Chorrochó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907806,29,'Cícero dantas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2907905,29,'Cipó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908002,29,'Coaraci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908101,29,'Cocos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908200,29,'Conceição da Feira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908309,29,'Conceição do Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908408,29,'Conceição do Coité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908507,29,'Conceição do Jacuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908606,29,'Conde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908705,29,'Condeúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908804,29,'Contendas do Sincorá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2908903,29,'Coração de Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909000,29,'Cordeiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909109,29,'Coribe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909208,29,'Coronel João Sá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909307,29,'Correntina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909406,29,'Cotegipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909505,29,'Cravolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909604,29,'Crisópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909703,29,'Cristópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909802,29,'Cruz das Almas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2909901,29,'Curaçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910008,29,'Dário Meira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910057,29,'Dias Dávila');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910107,29,'dom Basílio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910206,29,'dom Macedo Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910305,29,'Elísio Medrado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910404,29,'Encruzilhada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910503,29,'Entre Rios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910602,29,'Esplanada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910701,29,'Euclides da Cunha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910727,29,'Eunápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910750,29,'Fátima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910776,29,'Feira da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910800,29,'Feira de Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910859,29,'Filadélfia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2910909,29,'Firmino Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911006,29,'Floresta Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911105,29,'Formosa do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911204,29,'Gandu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911253,29,'Gavião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911303,29,'Gentio do Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911402,29,'Glória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911501,29,'Gongogi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911600,29,'Governador Mangabeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911659,29,'Guajeru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911709,29,'Guanambi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911808,29,'Guaratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911857,29,'Heliópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2911907,29,'Iaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912004,29,'Ibiassucê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912103,29,'Ibicaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912202,29,'Ibicoara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912301,29,'Ibicuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912400,29,'Ibipeba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912509,29,'Ibipitanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912608,29,'Ibiquera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912707,29,'Ibirapitanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912806,29,'Ibirapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2912905,29,'Ibirataia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913002,29,'Ibitiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913101,29,'Ibititá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913200,29,'Ibotirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913309,29,'Ichu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913408,29,'Igaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913457,29,'Igrapiúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913507,29,'Iguaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913606,29,'Ilhéus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913705,29,'Inhambupe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913804,29,'Ipecaetá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2913903,29,'Ipiaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914000,29,'Ipirá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914109,29,'Ipupiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914208,29,'Irajuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914307,29,'Iramaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914406,29,'Iraquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914505,29,'Irará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914604,29,'Irecê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914653,29,'Itabela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914703,29,'Itaberaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914802,29,'Itabuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2914901,29,'Itacaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915007,29,'Itaeté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915106,29,'Itagi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915205,29,'Itagibá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915304,29,'Itagimirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915353,29,'Itaguaçu da Bahia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915403,29,'Itaju do Colônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915502,29,'Itajuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915601,29,'Itamaraju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915700,29,'Itamari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915809,29,'Itambé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2915908,29,'Itanagra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916005,29,'Itanhém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916104,29,'Itaparica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916203,29,'Itapé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916302,29,'Itapebi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916401,29,'Itapetinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916500,29,'Itapicuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916609,29,'Itapitanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916708,29,'Itaquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916807,29,'Itarantim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916856,29,'Itatim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2916906,29,'Itiruçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917003,29,'Itiúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917102,29,'Itororó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917201,29,'Ituaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917300,29,'Ituberá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917334,29,'Iuiú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917359,29,'Jaborandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917409,29,'Jacaraci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917508,29,'Jacobina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917607,29,'Jaguaquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917706,29,'Jaguarari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917805,29,'Jaguaripe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2917904,29,'Jandaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918001,29,'Jequié');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918100,29,'Jeremoabo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918209,29,'Jiquiriçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918308,29,'Jitaúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918357,29,'João dourado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918407,29,'Juazeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918456,29,'Jucuruçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918506,29,'Jussara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918555,29,'Jussari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918605,29,'Jussiape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918704,29,'Lafaiete Coutinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918753,29,'Lagoa Real');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918803,29,'Laje');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2918902,29,'Lajedão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919009,29,'Lajedinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919058,29,'Lajedo do Tabocal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919108,29,'Lamarão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919157,29,'Lapão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919207,29,'Lauro de Freitas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919306,29,'Lençóis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919405,29,'Licínio de Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919504,29,'Livramento de Nossa Senhora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919553,29,'Luís Eduardo Magalhães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919603,29,'Macajuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919702,29,'Macarani');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919801,29,'Macaúbas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919900,29,'Macururé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919926,29,'Madre de deus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2919959,29,'Maetinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920007,29,'Maiquinique');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920106,29,'Mairi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920205,29,'Malhada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920304,29,'Malhada de Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920403,29,'Manoel Vitorino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920452,29,'Mansidão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920502,29,'Maracás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920601,29,'Maragogipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920700,29,'Maraú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920809,29,'Marcionílio Souza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2920908,29,'Mascote');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921005,29,'Mata de São João');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921054,29,'Matina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921104,29,'Medeiros Neto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921203,29,'Miguel Calmon');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921302,29,'Milagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921401,29,'Mirangaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921450,29,'Mirante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921500,29,'Monte Santo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921609,29,'Morpará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921708,29,'Morro do Chapéu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921807,29,'Mortugaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2921906,29,'Mucugê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922003,29,'Mucuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922052,29,'Mulungu do Morro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922102,29,'Mundo Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922201,29,'Muniz Ferreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922250,29,'Muquém de São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922300,29,'Muritiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922409,29,'Mutuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922508,29,'Nazaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922607,29,'Nilo Peçanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922656,29,'Nordestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922706,29,'Nova Canaã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922730,29,'Nova Fátima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922755,29,'Nova Ibiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922805,29,'Nova Itarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922854,29,'Nova Redenção');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2922904,29,'Nova Soure');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923001,29,'Nova Viçosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923035,29,'Novo Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923050,29,'Novo Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923100,29,'Olindina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923209,29,'Oliveira dos Brejinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923308,29,'Ouriçangas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923357,29,'Ourolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923407,29,'Palmas de Monte Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923506,29,'Palmeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923605,29,'Paramirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923704,29,'Paratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923803,29,'Paripiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2923902,29,'Pau Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924009,29,'Paulo Afonso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924058,29,'Pé de Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924108,29,'Pedrão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924207,29,'Pedro Alexandre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924306,29,'Piatã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924405,29,'Pilão Arcado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924504,29,'Pindaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924603,29,'Pindobaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924652,29,'Pintadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924678,29,'Piraí do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924702,29,'Piripá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924801,29,'Piritiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2924900,29,'Planaltino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925006,29,'Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925105,29,'Poções');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925204,29,'Pojuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925253,29,'Ponto Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925303,29,'Porto Seguro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925402,29,'Potiraguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925501,29,'Prado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925600,29,'Presidente Dutra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925709,29,'Presidente Jânio Quadros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925758,29,'Presidente Tancredo Neves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925808,29,'Queimadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925907,29,'Quijingue');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925931,29,'Quixabeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2925956,29,'Rafael Jambeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926004,29,'Remanso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926103,29,'Retirolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926202,29,'Riachão das Neves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926301,29,'Riachão do Jacuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926400,29,'Riacho de Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926509,29,'Ribeira do Amparo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926608,29,'Ribeira do Pombal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926657,29,'Ribeirão do Largo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926707,29,'Rio de Contas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926806,29,'Rio do Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2926905,29,'Rio do Pires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927002,29,'Rio Real');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927101,29,'Rodelas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927200,29,'Ruy Barbosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927309,29,'Salinas da Margarida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927408,29,'Salvador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927507,29,'Santa Bárbara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927606,29,'Santa Brígida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927705,29,'Santa Cruz Cabrália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927804,29,'Santa Cruz da Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2927903,29,'Santa Inês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928000,29,'Santaluz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928059,29,'Santa Luzia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928109,29,'Santa Maria da Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928208,29,'Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928307,29,'Santanópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928406,29,'Santa Rita de Cássia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928505,29,'Santa Teresinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928604,29,'Santo Amaro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928703,29,'Santo Antônio de Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928802,29,'Santo Estêvão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928901,29,'São desidério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2928950,29,'São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929008,29,'São Félix');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929057,29,'São Félix do Coribe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929107,29,'São Felipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929206,29,'São Francisco do Conde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929255,29,'São Gabriel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929305,29,'São Gonçalo dos Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929354,29,'São José da Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929370,29,'São José do Jacuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929404,29,'São Miguel das Matas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929503,29,'São Sebastião do Passé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929602,29,'Sapeaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929701,29,'Sátiro Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929750,29,'Saubara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929800,29,'Saúde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2929909,29,'Seabra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930006,29,'Sebastião Laranjeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930105,29,'Senhor do Bonfim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930154,29,'Serra do Ramalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930204,29,'Sento Sé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930303,29,'Serra dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930402,29,'Serra Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930501,29,'Serrinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930600,29,'Serrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930709,29,'Simões Filho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930758,29,'Sítio do Mato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930766,29,'Sítio do Quinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930774,29,'Sobradinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930808,29,'Souto Soares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2930907,29,'Tabocas do Brejo Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931004,29,'Tanhaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931053,29,'Tanque Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931103,29,'Tanquinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931202,29,'Taperoá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931301,29,'Tapiramutá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931350,29,'Teixeira de Freitas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931400,29,'Teodoro Sampaio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931509,29,'Teofilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931608,29,'Teolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931707,29,'Terra Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931806,29,'Tremedal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2931905,29,'Tucano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932002,29,'Uauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932101,29,'Ubaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932200,29,'Ubaitaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932309,29,'Ubatã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932408,29,'Uibaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932457,29,'Umburanas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932507,29,'Una');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932606,29,'Urandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932705,29,'Uruçuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932804,29,'Utinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2932903,29,'Valença');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933000,29,'Valente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933059,29,'Várzea da Roça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933109,29,'Várzea do Poço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933158,29,'Várzea Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933174,29,'Varzedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933208,29,'Vera Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933257,29,'Vereda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933307,29,'Vitória da Conquista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933406,29,'Wagner');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933455,29,'Wanderley');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933505,29,'Wenceslau Guimarães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(2933604,29,'Xique-Xique');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100104,31,'Abadia dos dourados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100203,31,'Abaeté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100302,31,'Abre Campo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100401,31,'Acaiaca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100500,31,'Açucena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100609,31,'Água Boa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100708,31,'Água Comprida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100807,31,'Aguanil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3100906,31,'Águas Formosas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101003,31,'Águas Vermelhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101102,31,'Aimorés');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101201,31,'Aiuruoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101300,31,'Alagoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101409,31,'Albertina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101508,31,'Além Paraíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101607,31,'Alfenas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101631,31,'Alfredo Vasconcelos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101706,31,'Almenara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101805,31,'Alpercata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3101904,31,'Alpinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102001,31,'Alterosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102050,31,'Alto Caparaó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102100,31,'Alto Rio doce');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102209,31,'Alvarenga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102308,31,'Alvinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102407,31,'Alvorada de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102506,31,'Amparo do Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102605,31,'Andradas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102704,31,'Cachoeira de Pajeú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102803,31,'Andrelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102852,31,'Angelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3102902,31,'Antônio Carlos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103009,31,'Antônio Dias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103108,31,'Antônio Prado de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103207,31,'Araçaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103306,31,'Aracitaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103405,31,'Araçuaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103504,31,'Araguari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103603,31,'Arantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103702,31,'Araponga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103751,31,'Araporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103801,31,'Arapuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3103900,31,'Araújos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104007,31,'Araxá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104106,31,'Arceburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104205,31,'Arcos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104304,31,'Areado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104403,31,'Argirita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104452,31,'Aricanduva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104502,31,'Arinos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104601,31,'Astolfo Dutra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104700,31,'Ataléia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104809,31,'Augusto de Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3104908,31,'Baependi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105004,31,'Baldim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105103,31,'Bambuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105202,31,'Bandeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105301,31,'Bandeira do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105400,31,'Barão de Cocais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105509,31,'Barão de Monte Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105608,31,'Barbacena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105707,31,'Barra Longa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3105905,31,'Barroso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106002,31,'Bela Vista de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106101,31,'Belmiro Braga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106200,31,'Belo Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106309,31,'Belo Oriente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106408,31,'Belo Vale');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106507,31,'Berilo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106606,31,'Bertópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106655,31,'Berizal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106705,31,'Betim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106804,31,'Bias Fortes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3106903,31,'Bicas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107000,31,'Biquinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107109,31,'Boa Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107208,31,'Bocaina de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107307,31,'Bocaiúva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107406,31,'Bom despacho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107505,31,'Bom Jardim de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107604,31,'Bom Jesus da Penha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107703,31,'Bom Jesus do Amparo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107802,31,'Bom Jesus do Galho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3107901,31,'Bom Repouso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108008,31,'Bom Sucesso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108107,31,'Bonfim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108206,31,'Bonfinópolis de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108255,31,'Bonito de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108305,31,'Borda da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108404,31,'Botelhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108503,31,'Botumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108552,31,'Brasilândia de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108602,31,'Brasília de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108701,31,'Brás Pires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108800,31,'Braúnas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3108909,31,'Brazópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109006,31,'Brumadinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109105,31,'Bueno Brandão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109204,31,'Buenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109253,31,'Bugre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109303,31,'Buritis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109402,31,'Buritizeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109451,31,'Cabeceira Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109501,31,'Cabo Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109600,31,'Cachoeira da Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109709,31,'Cachoeira de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109808,31,'Cachoeira dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3109907,31,'Caetanópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110004,31,'Caeté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110103,31,'Caiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110202,31,'Cajuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110301,31,'Caldas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110400,31,'Camacho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110509,31,'Camanducaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110608,31,'Cambuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110707,31,'Cambuquira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110806,31,'Campanário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3110905,31,'Campanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111002,31,'Campestre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111101,31,'Campina Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111150,31,'Campo Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111200,31,'Campo Belo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111309,31,'Campo do Meio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111408,31,'Campo Florido');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111507,31,'Campos Altos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111606,31,'Campos Gerais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111705,31,'Canaã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111804,31,'Canápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3111903,31,'Cana Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112000,31,'Candeias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112059,31,'Cantagalo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112109,31,'Caparaó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112208,31,'Capela Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112307,31,'Capelinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112406,31,'Capetinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112505,31,'Capim Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112604,31,'Capinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112653,31,'Capitão Andrade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112703,31,'Capitão Enéas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112802,31,'Capitólio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3112901,31,'Caputira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113008,31,'Caraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113107,31,'Caranaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113206,31,'Carandaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113305,31,'Carangola');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113404,31,'Caratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113503,31,'Carbonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113602,31,'Careaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113701,31,'Carlos Chagas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113800,31,'Carmésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3113909,31,'Carmo da Cachoeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114006,31,'Carmo da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114105,31,'Carmo de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114204,31,'Carmo do Cajuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114303,31,'Carmo do Paranaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114402,31,'Carmo do Rio Claro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114501,31,'Carmópolis de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114550,31,'Carneirinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114600,31,'Carrancas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114709,31,'Carvalhópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114808,31,'Carvalhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3114907,31,'Casa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115003,31,'Cascalho Rico');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115102,31,'Cássia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115201,31,'Conceição da Barra de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115300,31,'Cataguases');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115359,31,'Catas Altas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115409,31,'Catas Altas da Noruega');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115458,31,'Catuji');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115474,31,'Catuti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115508,31,'Caxambu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115607,31,'Cedro do Abaeté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115706,31,'Central de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115805,31,'Centralina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3115904,31,'Chácara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116001,31,'Chalé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116100,31,'Chapada do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116159,31,'Chapada Gaúcha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116209,31,'Chiador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116308,31,'Cipotânea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116407,31,'Claraval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116506,31,'Claro dos Poções');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116605,31,'Cláudio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116704,31,'Coimbra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116803,31,'Coluna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3116902,31,'Comendador Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117009,31,'Comercinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117108,31,'Conceição da Aparecida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117207,31,'Conceição das Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117306,31,'Conceição das Alagoas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117405,31,'Conceição de Ipanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117504,31,'Conceição do Mato dentro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117603,31,'Conceição do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117702,31,'Conceição do Rio Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117801,31,'Conceição dos Ouros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117836,31,'Cônego Marinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117876,31,'Confins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3117900,31,'Congonhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118007,31,'Congonhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118106,31,'Congonhas do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118205,31,'Conquista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118304,31,'Conselheiro Lafaiete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118403,31,'Conselheiro Pena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118502,31,'Consolação');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118601,31,'Contagem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118700,31,'Coqueiral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118809,31,'Coração de Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3118908,31,'Cordisburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119005,31,'Cordislândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119104,31,'Corinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119203,31,'Coroaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119302,31,'Coromandel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119401,31,'Coronel Fabriciano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119500,31,'Coronel Murta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119609,31,'Coronel Pacheco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119708,31,'Coronel Xavier Chaves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119807,31,'Córrego danta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119906,31,'Córrego do Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3119955,31,'Córrego Fundo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120003,31,'Córrego Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120102,31,'Couto de Magalhães de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120151,31,'Crisólita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120201,31,'Cristais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120300,31,'Cristália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120409,31,'Cristiano Otoni');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120508,31,'Cristina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120607,31,'Crucilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120706,31,'Cruzeiro da Fortaleza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120805,31,'Cruzília');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120839,31,'Cuparaque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120870,31,'Curral de dentro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3120904,31,'Curvelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121001,31,'datas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121100,31,'delfim Moreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121209,31,'delfinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121258,31,'delta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121308,31,'descoberto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121407,31,'desterro de Entre Rios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121506,31,'desterro do Melo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121605,31,'Diamantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121704,31,'Diogo de Vasconcelos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121803,31,'Dionísio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3121902,31,'Divinésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122009,31,'Divino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122108,31,'Divino das Laranjeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122207,31,'Divinolândia de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122306,31,'Divinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122355,31,'Divisa Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122405,31,'Divisa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122454,31,'Divisópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122470,31,'dom Bosco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122504,31,'dom Cavati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122603,31,'dom Joaquim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122702,31,'dom Silvério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122801,31,'dom Viçoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3122900,31,'dona Eusébia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123007,31,'dores de Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123106,31,'dores de Guanhães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123205,31,'dores do Indaiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123304,31,'dores do Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123403,31,'doresópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123502,31,'douradoquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123528,31,'Durandé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123601,31,'Elói Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123700,31,'Engenheiro Caldas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123809,31,'Engenheiro Navarro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123858,31,'Entre Folhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3123908,31,'Entre Rios de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124005,31,'Ervália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124104,31,'Esmeraldas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124203,31,'Espera Feliz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124302,31,'Espinosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124401,31,'Espírito Santo do dourado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124500,31,'Estiva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124609,31,'Estrela dalva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124708,31,'Estrela do Indaiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124807,31,'Estrela do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3124906,31,'Eugenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125002,31,'Ewbank da Câmara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125101,31,'Extrema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125200,31,'Fama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125309,31,'Faria Lemos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125408,31,'Felício dos Santos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125507,31,'São Gonçalo do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125606,31,'Felisburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125705,31,'Felixlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125804,31,'Fernandes Tourinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125903,31,'Ferros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3125952,31,'Fervedouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126000,31,'Florestal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126109,31,'Formiga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126208,31,'Formoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126307,31,'Fortaleza de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126406,31,'Fortuna de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126505,31,'Francisco Badaró');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126604,31,'Francisco Dumont');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126703,31,'Francisco Sá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126752,31,'Franciscópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126802,31,'Frei Gaspar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126901,31,'Frei Inocêncio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3126950,31,'Frei Lagonegro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127008,31,'Fronteira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127057,31,'Fronteira dos Vales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127073,31,'Fruta de Leite');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127107,31,'Frutal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127206,31,'Funilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127305,31,'Galiléia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127339,31,'Gameleiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127354,31,'Glaucilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127370,31,'Goiabeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127388,31,'Goianá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127404,31,'Gonçalves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127503,31,'Gonzaga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127602,31,'Gouveia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127701,31,'Governador Valadares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127800,31,'Grão Mogol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3127909,31,'Grupiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128006,31,'Guanhães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128105,31,'Guapé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128204,31,'Guaraciaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128253,31,'Guaraciama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128303,31,'Guaranésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128402,31,'Guarani');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128501,31,'Guarará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128600,31,'Guarda-Mor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128709,31,'Guaxupé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128808,31,'Guidoval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3128907,31,'Guimarânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129004,31,'Guiricema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129103,31,'Gurinhatã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129202,31,'Heliodora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129301,31,'Iapu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129400,31,'Ibertioga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129509,31,'Ibiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129608,31,'Ibiaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129657,31,'Ibiracatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129707,31,'Ibiraci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129806,31,'Ibirité');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3129905,31,'Ibitiúra de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130002,31,'Ibituruna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130051,31,'Icaraí de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130101,31,'Igarapé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130200,31,'Igaratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130309,31,'Iguatama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130408,31,'Ijaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130507,31,'Ilicínea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130556,31,'Imbé de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130606,31,'Inconfidentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130655,31,'Indaiabira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130705,31,'Indianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130804,31,'Ingaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3130903,31,'Inhapim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131000,31,'Inhaúma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131109,31,'Inimutaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131158,31,'Ipaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131208,31,'Ipanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131307,31,'Ipatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131406,31,'Ipiaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131505,31,'Ipuiúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131604,31,'Iraí de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131703,31,'Itabira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131802,31,'Itabirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3131901,31,'Itabirito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132008,31,'Itacambira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132107,31,'Itacarambi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132206,31,'Itaguara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132305,31,'Itaipé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132404,31,'Itajubá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132503,31,'Itamarandiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132602,31,'Itamarati de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132701,31,'Itambacuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132800,31,'Itambé do Mato dentro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3132909,31,'Itamogi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133006,31,'Itamonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133105,31,'Itanhandu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133204,31,'Itanhomi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133303,31,'Itaobim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133402,31,'Itapagipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133501,31,'Itapecerica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133600,31,'Itapeva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133709,31,'Itatiaiuçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133758,31,'Itaú de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133808,31,'Itaúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3133907,31,'Itaverava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134004,31,'Itinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134103,31,'Itueta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134202,31,'Ituiutaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134301,31,'Itumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134400,31,'Iturama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134509,31,'Itutinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134608,31,'Jaboticatubas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134707,31,'Jacinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134806,31,'Jacuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3134905,31,'Jacutinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135001,31,'Jaguaraçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135050,31,'Jaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135076,31,'Jampruca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135100,31,'Janaúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135209,31,'Januária');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135308,31,'Japaraíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135357,31,'Japonvar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135407,31,'Jeceaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135456,31,'Jenipapo de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135506,31,'Jequeri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135605,31,'Jequitaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135704,31,'Jequitibá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135803,31,'Jequitinhonha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3135902,31,'Jesuânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136009,31,'Joaíma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136108,31,'Joanésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136207,31,'João Monlevade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136306,31,'João Pinheiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136405,31,'Joaquim Felício');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136504,31,'Jordânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136520,31,'José Gonçalves de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136553,31,'José Raydan');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136579,31,'Josenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136603,31,'Nova União');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136652,31,'Juatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136702,31,'Juiz de Fora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136801,31,'Juramento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136900,31,'Juruaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3136959,31,'Juvenília');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137007,31,'Ladainha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137106,31,'Lagamar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137205,31,'Lagoa da Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137304,31,'Lagoa dos Patos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137403,31,'Lagoa dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137502,31,'Lagoa Formosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137536,31,'Lagoa Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137601,31,'Lagoa Santa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137700,31,'Lajinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137809,31,'Lambari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3137908,31,'Lamim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138005,31,'Laranjal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138104,31,'Lassance');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138203,31,'Lavras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138302,31,'Leandro Ferreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138351,31,'Leme do Prado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138401,31,'Leopoldina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138500,31,'Liberdade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138609,31,'Lima Duarte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138625,31,'Limeira do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138658,31,'Lontra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138674,31,'Luisburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138682,31,'Luislândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138708,31,'Luminárias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138807,31,'Luz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3138906,31,'Machacalis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139003,31,'Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139102,31,'Madre de deus de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139201,31,'Malacacheta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139250,31,'Mamonas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139300,31,'Manga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139409,31,'Manhuaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139508,31,'Manhumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139607,31,'Mantena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139706,31,'Maravilhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139805,31,'Mar de Espanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3139904,31,'Maria da Fé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140001,31,'Mariana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140100,31,'Marilac');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140159,31,'Mário Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140209,31,'Maripá de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140308,31,'Marliéria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140407,31,'Marmelópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140506,31,'Martinho Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140530,31,'Martins Soares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140555,31,'Mata Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140605,31,'Materlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140704,31,'Mateus Leme');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140803,31,'Matias Barbosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140852,31,'Matias Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3140902,31,'Matipó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141009,31,'Mato Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141108,31,'Matozinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141207,31,'Matutina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141306,31,'Medeiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141405,31,'Medina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141504,31,'Mendes Pimentel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141603,31,'Mercês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141702,31,'Mesquita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141801,31,'Minas Novas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3141900,31,'Minduri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142007,31,'Mirabela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142106,31,'Miradouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142205,31,'Miraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142254,31,'Miravânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142304,31,'Moeda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142403,31,'Moema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142502,31,'Monjolos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142601,31,'Monsenhor Paulo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142700,31,'Montalvânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142809,31,'Monte Alegre de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3142908,31,'Monte Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143005,31,'Monte Belo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143104,31,'Monte Carmelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143153,31,'Monte Formoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143203,31,'Monte Santo de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143302,31,'Montes Claros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143401,31,'Monte Sião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143450,31,'Montezuma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143500,31,'Morada Nova de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143609,31,'Morro da Garça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143708,31,'Morro do Pilar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143807,31,'Munhoz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3143906,31,'Muriaé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144003,31,'Mutum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144102,31,'Muzambinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144201,31,'Nacip Raydan');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144300,31,'Nanuque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144359,31,'Naque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144375,31,'Natalândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144409,31,'Natércia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144508,31,'Nazareno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144607,31,'Nepomuceno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144656,31,'Ninheira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144672,31,'Nova Belém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144706,31,'Nova Era');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144805,31,'Nova Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3144904,31,'Nova Módica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145000,31,'Nova Ponte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145059,31,'Nova Porteirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145109,31,'Nova Resende');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145208,31,'Nova Serrana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145307,31,'Novo Cruzeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145356,31,'Novo Oriente de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145372,31,'Novorizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145406,31,'Olaria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145455,31,'Olhos-Dágua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145505,31,'Olímpio Noronha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145604,31,'Oliveira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145703,31,'Oliveira Fortes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145802,31,'Onça de Pitangui');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145851,31,'Oratórios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145877,31,'Orizânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3145901,31,'Ouro Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146008,31,'Ouro Fino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146107,31,'Ouro Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146206,31,'Ouro Verde de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146255,31,'Padre Carvalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146305,31,'Padre Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146404,31,'Paineiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146503,31,'Pains');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146552,31,'Pai Pedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146602,31,'Paiva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146701,31,'Palma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146750,31,'Palmópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3146909,31,'Papagaios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147006,31,'Paracatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147105,31,'Pará de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147204,31,'Paraguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147303,31,'Paraisópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147402,31,'Paraopeba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147501,31,'Passabém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147600,31,'Passa Quatro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147709,31,'Passa Tempo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147808,31,'Passa-Vinte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147907,31,'Passos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3147956,31,'Patis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148004,31,'Patos de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148103,31,'Patrocínio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148202,31,'Patrocínio do Muriaé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148301,31,'Paula Cândido');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148400,31,'Paulistas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148509,31,'Pavão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148608,31,'Peçanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148707,31,'Pedra Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148756,31,'Pedra Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148806,31,'Pedra do Anta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3148905,31,'Pedra do Indaiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149002,31,'Pedra dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149101,31,'Pedralva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149150,31,'Pedras de Maria da Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149200,31,'Pedrinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149309,31,'Pedro Leopoldo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149408,31,'Pedro Teixeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149507,31,'Pequeri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149606,31,'Pequi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149705,31,'Perdigão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149804,31,'Perdizes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149903,31,'Perdões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3149952,31,'Periquito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150000,31,'Pescador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150109,31,'Piau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150158,31,'Piedade de Caratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150208,31,'Piedade de Ponte Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150307,31,'Piedade do Rio Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150406,31,'Piedade dos Gerais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150505,31,'Pimenta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150539,31,'Pingo-Dágua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150570,31,'Pintópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150604,31,'Piracema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150703,31,'Pirajuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150802,31,'Piranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3150901,31,'Piranguçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151008,31,'Piranguinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151107,31,'Pirapetinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151206,31,'Pirapora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151305,31,'Piraúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151404,31,'Pitangui');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151503,31,'Piumhi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151602,31,'Planura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151701,31,'Poço Fundo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151800,31,'Poços de Caldas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3151909,31,'Pocrane');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152006,31,'Pompéu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152105,31,'Ponte Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152131,31,'Ponto Chique');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152170,31,'Ponto dos Volantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152204,31,'Porteirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152303,31,'Porto Firme');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152402,31,'Poté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152501,31,'Pouso Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152600,31,'Pouso Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152709,31,'Prados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152808,31,'Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3152907,31,'Pratápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153004,31,'Pratinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153103,31,'Presidente Bernardes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153202,31,'Presidente Juscelino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153301,31,'Presidente Kubitschek');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153400,31,'Presidente Olegário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153509,31,'Alto Jequitibá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153608,31,'Prudente de Morais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153707,31,'Quartel Geral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153806,31,'Queluzito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3153905,31,'Raposos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154002,31,'Raul Soares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154101,31,'Recreio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154150,31,'Reduto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154200,31,'Resende Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154309,31,'Resplendor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154408,31,'Ressaquinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154457,31,'Riachinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154507,31,'Riacho dos Machados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154606,31,'Ribeirão das Neves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154705,31,'Ribeirão Vermelho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154804,31,'Rio Acima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3154903,31,'Rio Casca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155009,31,'Rio doce');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155108,31,'Rio do Prado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155207,31,'Rio Espera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155306,31,'Rio Manso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155405,31,'Rio Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155504,31,'Rio Paranaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155603,31,'Rio Pardo de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155702,31,'Rio Piracicaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155801,31,'Rio Pomba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3155900,31,'Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156007,31,'Rio Vermelho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156106,31,'Ritápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156205,31,'Rochedo de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156304,31,'Rodeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156403,31,'Romaria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156452,31,'Rosário da Limeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156502,31,'Rubelita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156601,31,'Rubim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156700,31,'Sabará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156809,31,'Sabinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3156908,31,'Sacramento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157005,31,'Salinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157104,31,'Salto da Divisa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157203,31,'Santa Bárbara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157252,31,'Santa Bárbara do Leste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157278,31,'Santa Bárbara do Monte Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157302,31,'Santa Bárbara do Tugúrio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157336,31,'Santa Cruz de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157377,31,'Santa Cruz de Salinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157401,31,'Santa Cruz do Escalvado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157500,31,'Santa Efigênia de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157609,31,'Santa Fé de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157658,31,'Santa Helena de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157708,31,'Santa Juliana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157807,31,'Santa Luzia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3157906,31,'Santa Margarida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158003,31,'Santa Maria de Itabira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158102,31,'Santa Maria do Salto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158201,31,'Santa Maria do Suaçuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158300,31,'Santana da Vargem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158409,31,'Santana de Cataguases');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158508,31,'Santana de Pirapama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158607,31,'Santana do deserto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158706,31,'Santana do Garambéu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158805,31,'Santana do Jacaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158904,31,'Santana do Manhuaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3158953,31,'Santana do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159001,31,'Santana do Riacho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159100,31,'Santana dos Montes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159209,31,'Santa Rita de Caldas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159308,31,'Santa Rita de Jacutinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159357,31,'Santa Rita de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159407,31,'Santa Rita de Ibitipoca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159506,31,'Santa Rita do Itueto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159605,31,'Santa Rita do Sapucaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159704,31,'Santa Rosa da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159803,31,'Santa Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3159902,31,'Santo Antônio do Amparo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160009,31,'Santo Antônio do Aventureiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160108,31,'Santo Antônio do Grama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160207,31,'Santo Antônio do Itambé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160306,31,'Santo Antônio do Jacinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160405,31,'Santo Antônio do Monte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160454,31,'Santo Antônio do Retiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160504,31,'Santo Antônio do Rio Abaixo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160603,31,'Santo Hipólito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160702,31,'Santos Dumont');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160801,31,'São Bento Abade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160900,31,'São Brás do Suaçuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3160959,31,'São domingos das dores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161007,31,'São domingos do Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161056,31,'São Félix de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161106,31,'São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161205,31,'São Francisco de Paula');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161304,31,'São Francisco de Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161403,31,'São Francisco do Glória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161502,31,'São Geraldo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161601,31,'São Geraldo da Piedade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161650,31,'São Geraldo do Baixio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161700,31,'São Gonçalo do Abaeté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161809,31,'São Gonçalo do Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3161908,31,'São Gonçalo do Rio Abaixo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162005,31,'São Gonçalo do Sapucaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162104,31,'São Gotardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162203,31,'São João Batista do Glória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162252,31,'São João da Lagoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162302,31,'São João da Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162401,31,'São João da Ponte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162450,31,'São João das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162500,31,'São João del Rei');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162559,31,'São João do Manhuaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162575,31,'São João do Manteninha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162609,31,'São João do Oriente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162658,31,'São João do Pacuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162708,31,'São João do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162807,31,'São João Evangelista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162906,31,'São João Nepomuceno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162922,31,'São Joaquim de Bicas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162948,31,'São José da Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3162955,31,'São José da Lapa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163003,31,'São José da Safira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163102,31,'São José da Varginha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163201,31,'São José do Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163300,31,'São José do Divino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163409,31,'São José do Goiabal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163508,31,'São José do Jacuri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163607,31,'São José do Mantimento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163706,31,'São Lourenço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163805,31,'São Miguel do Anta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3163904,31,'São Pedro da União');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164001,31,'São Pedro dos Ferros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164100,31,'São Pedro do Suaçuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164209,31,'São Romão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164308,31,'São Roque de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164407,31,'São Sebastião da Bela Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164431,31,'São Sebastião da Vargem Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164472,31,'São Sebastião do Anta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164506,31,'São Sebastião do Maranhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164605,31,'São Sebastião do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164704,31,'São Sebastião do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164803,31,'São Sebastião do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3164902,31,'São Sebastião do Rio Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165008,31,'São Tiago');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165107,31,'São Tomás de Aquino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165206,31,'São Thomé das Letras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165305,31,'São Vicente de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165404,31,'Sapucaí-Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165503,31,'Sardoá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165537,31,'Sarzedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165552,31,'Setubinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165560,31,'Sem-Peixe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165578,31,'Senador Amaral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165602,31,'Senador Cortes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165701,31,'Senador Firmino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165800,31,'Senador José Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3165909,31,'Senador Modestino Gonçalves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166006,31,'Senhora de Oliveira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166105,31,'Senhora do Porto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166204,31,'Senhora dos Remédios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166303,31,'Sericita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166402,31,'Seritinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166501,31,'Serra Azul de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166600,31,'Serra da Saudade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166709,31,'Serra dos Aimorés');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166808,31,'Serra do Salitre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166907,31,'Serrania');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3166956,31,'Serranópolis de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167004,31,'Serranos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167103,31,'Serro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167202,31,'Sete Lagoas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167301,31,'Silveirânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167400,31,'Silvianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167509,31,'Simão Pereira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167608,31,'Simonésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167707,31,'Sobrália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167806,31,'Soledade de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3167905,31,'Tabuleiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168002,31,'Taiobeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168051,31,'Taparuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168101,31,'Tapira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168200,31,'Tapiraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168309,31,'Taquaraçu de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168408,31,'Tarumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168507,31,'Teixeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168606,31,'Teófilo Otoni');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168705,31,'Timóteo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168804,31,'Tiradentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3168903,31,'Tiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169000,31,'Tocantins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169059,31,'Tocos do Moji');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169109,31,'Toledo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169208,31,'Tombos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169307,31,'Três Corações');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169356,31,'Três Marias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169406,31,'Três Pontas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169505,31,'Tumiritinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169604,31,'Tupaciguara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169703,31,'Turmalina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169802,31,'Turvolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3169901,31,'Ubá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170008,31,'Ubaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170057,31,'Ubaporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170107,31,'Uberaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170206,31,'Uberlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170305,31,'Umburatiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170404,31,'Unaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170438,31,'União de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170479,31,'Uruana de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170503,31,'Urucânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170529,31,'Urucuia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170578,31,'Vargem Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170602,31,'Vargem Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170651,31,'Vargem Grande do Rio Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170701,31,'Varginha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170750,31,'Varjão de Minas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170800,31,'Várzea da Palma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3170909,31,'Varzelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171006,31,'Vazante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171030,31,'Verdelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171071,31,'Veredinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171105,31,'Veríssimo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171154,31,'Vermelho Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171204,31,'Vespasiano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171303,31,'Viçosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171402,31,'Vieiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171501,31,'Mathias Lobato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171600,31,'Virgem da Lapa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171709,31,'Virgínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171808,31,'Virginópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3171907,31,'Virgolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3172004,31,'Visconde do Rio Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3172103,31,'Volta Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3172202,31,'Wenceslau Braz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200102,32,'Afonso Cláudio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200136,32,'Águia Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200169,32,'Água doce do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200201,32,'Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200300,32,'Alfredo Chaves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200359,32,'Alto Rio Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200409,32,'Anchieta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200508,32,'Apiacá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200607,32,'Aracruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200706,32,'Atilio Vivacqua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200805,32,'Baixo Guandu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3200904,32,'Barra de São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201001,32,'Boa Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201100,32,'Bom Jesus do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201159,32,'Brejetuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201209,32,'Cachoeiro de Itapemirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201308,32,'Cariacica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201407,32,'Castelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201506,32,'Colatina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201605,32,'Conceição da Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201704,32,'Conceição do Castelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201803,32,'Divino de São Lourenço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3201902,32,'domingos Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202009,32,'dores do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202108,32,'Ecoporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202207,32,'Fundão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202256,32,'Governador Lindenberg');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202306,32,'Guaçuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202405,32,'Guarapari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202454,32,'Ibatiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202504,32,'Ibiraçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202553,32,'Ibitirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202603,32,'Iconha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202652,32,'Irupi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202702,32,'Itaguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202801,32,'Itapemirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3202900,32,'Itarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203007,32,'Iúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203056,32,'Jaguaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203106,32,'Jerônimo Monteiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203130,32,'João Neiva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203163,32,'Laranja da Terra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203205,32,'Linhares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203304,32,'Mantenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203320,32,'Marataízes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203346,32,'Marechal Floriano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203353,32,'Marilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203403,32,'Mimoso do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203502,32,'Montanha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203601,32,'Mucurici');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203700,32,'Muniz Freire');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203809,32,'Muqui');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3203908,32,'Nova Venécia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204005,32,'Pancas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204054,32,'Pedro Canário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204104,32,'Pinheiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204203,32,'Piúma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204252,32,'Ponto Belo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204302,32,'Presidente Kennedy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204351,32,'Rio Bananal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204401,32,'Rio Novo do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204500,32,'Santa Leopoldina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204559,32,'Santa Maria de Jetibá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204609,32,'Santa Teresa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204658,32,'São domingos do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204708,32,'São Gabriel da Palha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204807,32,'São José do Calçado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204906,32,'São Mateus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3204955,32,'São Roque do Canaã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205002,32,'Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205010,32,'Sooretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205036,32,'Vargem Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205069,32,'Venda Nova do Imigrante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205101,32,'Viana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205150,32,'Vila Pavão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205176,32,'Vila Valério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205200,32,'Vila Velha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3205309,32,'Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300100,33,'Angra dos Reis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300159,33,'Aperibé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300209,33,'Araruama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300225,33,'Areal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300233,33,'Armação dos Búzios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300258,33,'Arraial do Cabo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300308,33,'Barra do Piraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300407,33,'Barra Mansa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300456,33,'Belford Roxo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300506,33,'Bom Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300605,33,'Bom Jesus do Itabapoana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300704,33,'Cabo Frio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300803,33,'Cachoeiras de Macacu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300902,33,'Cambuci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300936,33,'Carapebus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3300951,33,'Comendador Levy Gasparian');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301009,33,'Campos dos Goytacazes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301108,33,'Cantagalo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301157,33,'Cardoso Moreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301207,33,'Carmo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301306,33,'Casimiro de Abreu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301405,33,'Conceição de Macabu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301504,33,'Cordeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301603,33,'Duas Barras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301702,33,'Duque de Caxias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301801,33,'Engenheiro Paulo de Frontin');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301850,33,'Guapimirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301876,33,'Iguaba Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3301900,33,'Itaboraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302007,33,'Itaguaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302056,33,'Italva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302106,33,'Itaocara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302205,33,'Itaperuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302254,33,'Itatiaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302270,33,'Japeri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302304,33,'Laje do Muriaé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302403,33,'Macaé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302452,33,'Macuco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302502,33,'Magé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302601,33,'Mangaratiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302700,33,'Maricá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302809,33,'Mendes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302858,33,'Mesquita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3302908,33,'Miguel Pereira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303005,33,'Miracema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303104,33,'Natividade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303203,33,'Nilópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303302,33,'Niterói');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303401,33,'Nova Friburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303500,33,'Nova Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303609,33,'Paracambi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303708,33,'Paraíba do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303807,33,'Paraty');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303856,33,'Paty do Alferes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303906,33,'Petrópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3303955,33,'Pinheiral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304003,33,'Piraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304102,33,'Porciúncula');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304110,33,'Porto Real');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304128,33,'Quatis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304144,33,'Queimados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304151,33,'Quissamã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304201,33,'Resende');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304300,33,'Rio Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304409,33,'Rio Claro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304508,33,'Rio das Flores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304524,33,'Rio das Ostras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304557,33,'Rio de Janeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304607,33,'Santa Maria Madalena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304706,33,'Santo Antônio de Pádua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304755,33,'São Francisco de Itabapoana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304805,33,'São Fidélis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3304904,33,'São Gonçalo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305000,33,'São João da Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305109,33,'São João de Meriti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305133,33,'São José de Ubá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305158,33,'São José do Vale do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305208,33,'São Pedro da Aldeia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305307,33,'São Sebastião do Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305406,33,'Sapucaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305505,33,'Saquarema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305554,33,'Seropédica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305604,33,'Silva Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305703,33,'Sumidouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305752,33,'Tanguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305802,33,'Teresópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3305901,33,'Trajano de Moraes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3306008,33,'Três Rios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3306107,33,'Valença');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3306156,33,'Varre-Sai');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3306206,33,'Vassouras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3306305,33,'Volta Redonda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500105,35,'Adamantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500204,35,'Adolfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500303,35,'Aguaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500402,35,'Águas da Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500501,35,'Águas de Lindóia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500550,35,'Águas de Santa Bárbara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500600,35,'Águas de São Pedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500709,35,'Agudos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500758,35,'Alambari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500808,35,'Alfredo Marcondes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3500907,35,'Altair');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501004,35,'Altinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501103,35,'Alto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501152,35,'Alumínio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501202,35,'Álvares Florence');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501301,35,'Álvares Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501400,35,'Álvaro de Carvalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501509,35,'Alvinlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501608,35,'Americana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501707,35,'Américo Brasiliense');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501806,35,'Américo de Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3501905,35,'Amparo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502002,35,'Analândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502101,35,'Andradina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502200,35,'Angatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502309,35,'Anhembi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502408,35,'Anhumas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502507,35,'Aparecida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502606,35,'Aparecida Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502705,35,'Apiaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502754,35,'Araçariguama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502804,35,'Araçatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3502903,35,'Araçoiaba da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503000,35,'Aramina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503109,35,'Arandu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503158,35,'Arapeí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503208,35,'Araraquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503307,35,'Araras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503356,35,'Arco-Íris');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503406,35,'Arealva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503505,35,'Areias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503604,35,'Areiópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503703,35,'Ariranha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503802,35,'Artur Nogueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503901,35,'Arujá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3503950,35,'Aspásia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504008,35,'Assis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504107,35,'Atibaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504206,35,'Auriflama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504305,35,'Avaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504404,35,'Avanhandava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504503,35,'Avaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504602,35,'Bady Bassitt');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504701,35,'Balbinos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504800,35,'Bálsamo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3504909,35,'Bananal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505005,35,'Barão de Antonina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505104,35,'Barbosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505203,35,'Bariri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505302,35,'Barra Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505351,35,'Barra do Chapéu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505401,35,'Barra do Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505500,35,'Barretos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505609,35,'Barrinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505708,35,'Barueri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505807,35,'Bastos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3505906,35,'Batatais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506003,35,'Bauru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506102,35,'Bebedouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506201,35,'Bento de Abreu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506300,35,'Bernardino de Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506359,35,'Bertioga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506409,35,'Bilac');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506508,35,'Birigui');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506607,35,'Biritiba-Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506706,35,'Boa Esperança do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506805,35,'Bocaina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3506904,35,'Bofete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507001,35,'Boituva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507100,35,'Bom Jesus dos Perdões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507159,35,'Bom Sucesso de Itararé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507209,35,'Borá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507308,35,'Boracéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507407,35,'Borborema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507456,35,'Borebi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507506,35,'Botucatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507605,35,'Bragança Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507704,35,'Braúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507753,35,'Brejo Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507803,35,'Brodowski');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3507902,35,'Brotas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508009,35,'Buri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508108,35,'Buritama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508207,35,'Buritizal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508306,35,'Cabrália Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508405,35,'Cabreúva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508504,35,'Caçapava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508603,35,'Cachoeira Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508702,35,'Caconde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508801,35,'Cafelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3508900,35,'Caiabu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509007,35,'Caieiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509106,35,'Caiuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509205,35,'Cajamar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509254,35,'Cajati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509304,35,'Cajobi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509403,35,'Cajuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509452,35,'Campina do Monte Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509502,35,'Campinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509601,35,'Campo Limpo Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509700,35,'Campos do Jordão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509809,35,'Campos Novos Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509908,35,'Cananéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3509957,35,'Canas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510005,35,'Cândido Mota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510104,35,'Cândido Rodrigues');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510153,35,'Canitar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510203,35,'Capão Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510302,35,'Capela do Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510401,35,'Capivari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510500,35,'Caraguatatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510609,35,'Carapicuíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510708,35,'Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510807,35,'Casa Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3510906,35,'Cássia dos Coqueiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511003,35,'Castilho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511102,35,'Catanduva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511201,35,'Catiguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511300,35,'Cedral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511409,35,'Cerqueira César');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511508,35,'Cerquilho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511607,35,'Cesário Lange');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511706,35,'Charqueada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3511904,35,'Clementina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512001,35,'Colina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512100,35,'Colômbia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512209,35,'Conchal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512308,35,'Conchas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512407,35,'Cordeirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512506,35,'Coroados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512605,35,'Coronel Macedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512704,35,'Corumbataí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512803,35,'Cosmópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3512902,35,'Cosmorama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513009,35,'Cotia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513108,35,'Cravinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513207,35,'Cristais Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513306,35,'Cruzália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513405,35,'Cruzeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513504,35,'Cubatão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513603,35,'Cunha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513702,35,'descalvado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513801,35,'Diadema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513850,35,'Dirce Reis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3513900,35,'Divinolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514007,35,'dobrada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514106,35,'dois Córregos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514205,35,'dolcinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514304,35,'dourado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514403,35,'Dracena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514502,35,'Duartina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514601,35,'Dumont');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514700,35,'Echaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514809,35,'Eldorado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514908,35,'Elias Fausto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514924,35,'Elisiário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3514957,35,'Embaúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515004,35,'Embu das Artes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515103,35,'Embu-Guaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515129,35,'Emilianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515152,35,'Engenheiro Coelho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515186,35,'Espírito Santo do Pinhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515194,35,'Espírito Santo do Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515202,35,'Estrela Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515301,35,'Estrela do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515350,35,'Euclides da Cunha Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515400,35,'Fartura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515509,35,'Fernandópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515608,35,'Fernando Prestes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515657,35,'Fernão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515707,35,'Ferraz de Vasconcelos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515806,35,'Flora Rica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3515905,35,'Floreal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516002,35,'Flórida Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516101,35,'Florínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516200,35,'Franca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516309,35,'Francisco Morato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516408,35,'Franco da Rocha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516507,35,'Gabriel Monteiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516606,35,'Gália');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516705,35,'Garça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516804,35,'Gastão Vidigal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516853,35,'Gavião Peixoto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3516903,35,'General Salgado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517000,35,'Getulina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517109,35,'Glicério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517208,35,'Guaiçara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517307,35,'Guaimbê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517406,35,'Guaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517505,35,'Guapiaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517604,35,'Guapiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517703,35,'Guará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517802,35,'Guaraçaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3517901,35,'Guaraci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518008,35,'Guarani Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518107,35,'Guarantã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518206,35,'Guararapes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518305,35,'Guararema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518404,35,'Guaratinguetá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518503,35,'Guareí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518602,35,'Guariba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518701,35,'Guarujá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518800,35,'Guarulhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518859,35,'Guatapará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3518909,35,'Guzolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519006,35,'Herculândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519055,35,'Holambra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519071,35,'Hortolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519105,35,'Iacanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519204,35,'Iacri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519253,35,'Iaras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519303,35,'Ibaté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519402,35,'Ibirá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519501,35,'Ibirarema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519600,35,'Ibitinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519709,35,'Ibiúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519808,35,'Icém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3519907,35,'Iepê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520004,35,'Igaraçu do Tietê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520103,35,'Igarapava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520202,35,'Igaratá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520301,35,'Iguape');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520400,35,'Ilhabela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520426,35,'Ilha Comprida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520442,35,'Ilha Solteira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520509,35,'Indaiatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520608,35,'Indiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520707,35,'Indiaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520806,35,'Inúbia Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3520905,35,'Ipaussu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521002,35,'Iperó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521101,35,'Ipeúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521150,35,'Ipiguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521200,35,'Iporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521309,35,'Ipuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521408,35,'Iracemápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521507,35,'Irapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521606,35,'Irapuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521705,35,'Itaberá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521804,35,'Itaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3521903,35,'Itajobi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522000,35,'Itaju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522109,35,'Itanhaém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522158,35,'Itaóca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522208,35,'Itapecerica da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522307,35,'Itapetininga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522406,35,'Itapeva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522505,35,'Itapevi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522604,35,'Itapira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522653,35,'Itapirapuã Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522703,35,'Itápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522802,35,'Itaporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3522901,35,'Itapuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523008,35,'Itapura');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523107,35,'Itaquaquecetuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523206,35,'Itararé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523305,35,'Itariri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523404,35,'Itatiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523503,35,'Itatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523602,35,'Itirapina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523701,35,'Itirapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523800,35,'Itobi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3523909,35,'Itu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524006,35,'Itupeva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524105,35,'Ituverava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524204,35,'Jaborandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524303,35,'Jaboticabal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524402,35,'Jacareí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524501,35,'Jaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524600,35,'Jacupiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524709,35,'Jaguariúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524808,35,'Jales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3524907,35,'Jambeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525003,35,'Jandira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525102,35,'Jardinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525201,35,'Jarinu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525300,35,'Jaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525409,35,'Jeriquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525508,35,'Joanópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525607,35,'João Ramalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525706,35,'José Bonifácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525805,35,'Júlio Mesquita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525854,35,'Jumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3525904,35,'Jundiaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526001,35,'Junqueirópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526100,35,'Juquiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526209,35,'Juquitiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526308,35,'Lagoinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526407,35,'Laranjal Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526506,35,'Lavínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526605,35,'Lavrinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526704,35,'Leme');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526803,35,'Lençóis Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3526902,35,'Limeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527009,35,'Lindóia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527108,35,'Lins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527207,35,'Lorena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527256,35,'Lourdes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527306,35,'Louveira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527405,35,'Lucélia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527504,35,'Lucianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527603,35,'Luís Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527702,35,'Luiziânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527801,35,'Lupércio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3527900,35,'Lutécia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528007,35,'Macatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528106,35,'Macaubal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528205,35,'Macedônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528304,35,'Magda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528403,35,'Mairinque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528502,35,'Mairiporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528601,35,'Manduri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528700,35,'Marabá Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528809,35,'Maracaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528858,35,'Marapoama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3528908,35,'Mariápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529005,35,'Marília');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529104,35,'Marinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529203,35,'Martinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529302,35,'Matão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529401,35,'Mauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529500,35,'Mendonça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529609,35,'Meridiano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529658,35,'Mesópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529708,35,'Miguelópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529807,35,'Mineiros do Tietê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3529906,35,'Miracatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530003,35,'Mira Estrela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530102,35,'Mirandópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530201,35,'Mirante do Paranapanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530300,35,'Mirassol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530409,35,'Mirassolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530508,35,'Mococa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530607,35,'Mogi das Cruzes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530706,35,'Mogi Guaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530805,35,'Mogi Mirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3530904,35,'Mombuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531001,35,'Monções');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531100,35,'Mongaguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531209,35,'Monte Alegre do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531308,35,'Monte Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531407,35,'Monte Aprazível');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531506,35,'Monte Azul Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531605,35,'Monte Castelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531704,35,'Monteiro Lobato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531803,35,'Monte Mor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3531902,35,'Morro Agudo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532009,35,'Morungaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532058,35,'Motuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532108,35,'Murutinga do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532157,35,'Nantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532207,35,'Narandiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532306,35,'Natividade da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532405,35,'Nazaré Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532504,35,'Neves Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532603,35,'Nhandeara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532702,35,'Nipoã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532801,35,'Nova Aliança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532827,35,'Nova Campina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532843,35,'Nova Canaã Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532868,35,'Nova Castilho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3532900,35,'Nova Europa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533007,35,'Nova Granada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533106,35,'Nova Guataporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533205,35,'Nova Independência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533254,35,'Novais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533304,35,'Nova Luzitânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533403,35,'Nova Odessa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533502,35,'Novo Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533601,35,'Nuporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533700,35,'Ocauçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533809,35,'Óleo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3533908,35,'Olímpia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534005,35,'Onda Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534104,35,'Oriente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534203,35,'Orindiúva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534302,35,'Orlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534401,35,'Osasco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534500,35,'Oscar Bressane');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534609,35,'Osvaldo Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534708,35,'Ourinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534757,35,'Ouroeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534807,35,'Ouro Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3534906,35,'Pacaembu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535002,35,'Palestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535101,35,'Palmares Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535200,35,'Palmeira Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535309,35,'Palmital');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535408,35,'Panorama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535507,35,'Paraguaçu Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535606,35,'Paraibuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535705,35,'Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535804,35,'Paranapanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3535903,35,'Paranapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536000,35,'Parapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536109,35,'Pardinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536208,35,'Pariquera-Açu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536257,35,'Parisi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536307,35,'Patrocínio Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536406,35,'Paulicéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536505,35,'Paulínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536570,35,'Paulistânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536604,35,'Paulo de Faria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536703,35,'Pederneiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536802,35,'Pedra Bela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3536901,35,'Pedranópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537008,35,'Pedregulho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537107,35,'Pedreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537156,35,'Pedrinhas Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537206,35,'Pedro de Toledo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537305,35,'Penápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537404,35,'Pereira Barreto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537503,35,'Pereiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537602,35,'Peruíbe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537701,35,'Piacatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537800,35,'Piedade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3537909,35,'Pilar do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538006,35,'Pindamonhangaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538105,35,'Pindorama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538204,35,'Pinhalzinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538303,35,'Piquerobi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538501,35,'Piquete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538600,35,'Piracaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538709,35,'Piracicaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538808,35,'Piraju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3538907,35,'Pirajuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539004,35,'Pirangi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539103,35,'Pirapora do Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539202,35,'Pirapozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539301,35,'Pirassununga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539400,35,'Piratininga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539509,35,'Pitangueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539608,35,'Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539707,35,'Platina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539806,35,'Poá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3539905,35,'Poloni');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540002,35,'Pompéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540101,35,'Pongaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540200,35,'Pontal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540259,35,'Pontalinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540309,35,'Pontes Gestal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540408,35,'Populina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540507,35,'Porangaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540606,35,'Porto Feliz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540705,35,'Porto Ferreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540754,35,'Potim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540804,35,'Potirendaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540853,35,'Pracinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3540903,35,'Pradópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541000,35,'Praia Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541059,35,'Pratânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541109,35,'Presidente Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541208,35,'Presidente Bernardes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541307,35,'Presidente Epitácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541406,35,'Presidente Prudente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541505,35,'Presidente Venceslau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541604,35,'Promissão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541653,35,'Quadra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541703,35,'Quatá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541802,35,'Queiroz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3541901,35,'Queluz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542008,35,'Quintana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542107,35,'Rafard');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542206,35,'Rancharia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542305,35,'Redenção da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542404,35,'Regente Feijó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542503,35,'Reginópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542602,35,'Registro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542701,35,'Restinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542800,35,'Ribeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3542909,35,'Ribeirão Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543006,35,'Ribeirão Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543105,35,'Ribeirão Corrente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543204,35,'Ribeirão do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543238,35,'Ribeirão dos Índios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543253,35,'Ribeirão Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543303,35,'Ribeirão Pires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543402,35,'Ribeirão Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543501,35,'Riversul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543600,35,'Rifaina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543709,35,'Rincão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543808,35,'Rinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3543907,35,'Rio Claro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544004,35,'Rio das Pedras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544103,35,'Rio Grande da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544202,35,'Riolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544251,35,'Rosana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544301,35,'Roseira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544400,35,'Rubiácea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544509,35,'Rubinéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544608,35,'Sabino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544707,35,'Sagres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544806,35,'Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3544905,35,'Sales Oliveira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545001,35,'Salesópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545100,35,'Salmourão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545159,35,'Saltinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545209,35,'Salto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545308,35,'Salto de Pirapora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545407,35,'Salto Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545506,35,'Sandovalina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545605,35,'Santa Adélia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545704,35,'Santa Albertina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3545803,35,'Santa Bárbara Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546009,35,'Santa Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546108,35,'Santa Clara Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546207,35,'Santa Cruz da Conceição');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546256,35,'Santa Cruz da Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546306,35,'Santa Cruz das Palmeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546405,35,'Santa Cruz do Rio Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546504,35,'Santa Ernestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546603,35,'Santa Fé do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546702,35,'Santa Gertrudes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546801,35,'Santa Isabel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3546900,35,'Santa Lúcia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547007,35,'Santa Maria da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547106,35,'Santa Mercedes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547205,35,'Santana da Ponte Pensa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547304,35,'Santana de Parnaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547403,35,'Santa Rita Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547502,35,'Santa Rita do Passa Quatro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547601,35,'Santa Rosa de Viterbo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547650,35,'Santa Salete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547700,35,'Santo Anastácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547809,35,'Santo André');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3547908,35,'Santo Antônio da Alegria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548005,35,'Santo Antônio de Posse');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548054,35,'Santo Antônio do Aracanguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548104,35,'Santo Antônio do Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548203,35,'Santo Antônio do Pinhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548302,35,'Santo Expedito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548401,35,'Santópolis do Aguapeí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548500,35,'Santos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548609,35,'São Bento do Sapucaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548708,35,'São Bernardo do Campo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548807,35,'São Caetano do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3548906,35,'São Carlos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549003,35,'São Francisco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549102,35,'São João da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549201,35,'São João das Duas Pontes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549250,35,'São João de Iracema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549300,35,'São João do Pau Dalho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549409,35,'São Joaquim da Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549508,35,'São José da Bela Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549607,35,'São José do Barreiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549706,35,'São José do Rio Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549805,35,'São José do Rio Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549904,35,'São José dos Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3549953,35,'São Lourenço da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550001,35,'São Luís do Paraitinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550100,35,'São Manuel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550209,35,'São Miguel Arcanjo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550308,35,'São Paulo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550407,35,'São Pedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550506,35,'São Pedro do Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550605,35,'São Roque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550704,35,'São Sebastião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550803,35,'São Sebastião da Grama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3550902,35,'São Simão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551009,35,'São Vicente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551108,35,'Sarapuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551207,35,'Sarutaiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551306,35,'Sebastianópolis do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551405,35,'Serra Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551504,35,'Serrana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551603,35,'Serra Negra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551702,35,'Sertãozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551801,35,'Sete Barras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3551900,35,'Severínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552007,35,'Silveiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552106,35,'Socorro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552205,35,'Sorocaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552304,35,'Sud Mennucci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552403,35,'Sumaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552502,35,'Suzano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552551,35,'Suzanápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552601,35,'Tabapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552700,35,'Tabatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552809,35,'Taboão da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3552908,35,'Taciba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553005,35,'Taguaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553104,35,'Taiaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553203,35,'Taiúva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553302,35,'Tambaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553401,35,'Tanabi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553500,35,'Tapiraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553609,35,'Tapiratiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553658,35,'Taquaral');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553708,35,'Taquaritinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553807,35,'Taquarituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553856,35,'Taquarivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553906,35,'Tarabai');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3553955,35,'Tarumã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554003,35,'Tatuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554102,35,'Taubaté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554201,35,'Tejupá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554300,35,'Teodoro Sampaio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554409,35,'Terra Roxa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554508,35,'Tietê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554607,35,'Timburi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554656,35,'Torre de Pedra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554706,35,'Torrinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554755,35,'Trabiju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554805,35,'Tremembé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554904,35,'Três Fronteiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3554953,35,'Tuiuti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555000,35,'Tupã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555109,35,'Tupi Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555208,35,'Turiúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555307,35,'Turmalina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555356,35,'Ubarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555406,35,'Ubatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555505,35,'Ubirajara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555604,35,'Uchoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555703,35,'União Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555802,35,'Urânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3555901,35,'Uru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556008,35,'Urupês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556107,35,'Valentim Gentil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556206,35,'Valinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556305,35,'Valparaíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556354,35,'Vargem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556404,35,'Vargem Grande do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556453,35,'Vargem Grande Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556503,35,'Várzea Paulista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556602,35,'Vera Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556701,35,'Vinhedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556800,35,'Viradouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556909,35,'Vista Alegre do Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3556958,35,'Vitória Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3557006,35,'Votorantim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3557105,35,'Votuporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3557154,35,'Zacarias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3557204,35,'Chavantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(3557303,35,'Estiva Gerbi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100103,41,'Abatiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100202,41,'Adrianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100301,41,'Agudos do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100400,41,'Almirante Tamandaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100459,41,'Altamira do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100509,41,'Altônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100608,41,'Alto Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100707,41,'Alto Piquiri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100806,41,'Alvorada do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4100905,41,'Amaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101002,41,'Ampére');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101051,41,'Anahy');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101101,41,'Andirá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101150,41,'Ângulo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101200,41,'Antonina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101309,41,'Antônio Olinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101408,41,'Apucarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101507,41,'Arapongas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101606,41,'Arapoti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101655,41,'Arapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101705,41,'Araruna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101804,41,'Araucária');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101853,41,'Ariranha do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4101903,41,'Assaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102000,41,'Assis Chateaubriand');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102109,41,'Astorga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102208,41,'Atalaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102307,41,'Balsa Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102406,41,'Bandeirantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102505,41,'Barbosa Ferraz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102604,41,'Barracão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102703,41,'Barra do Jacaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102752,41,'Bela Vista da Caroba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102802,41,'Bela Vista do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4102901,41,'Bituruna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103008,41,'Boa Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103024,41,'Boa Esperança do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103040,41,'Boa Ventura de São Roque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103057,41,'Boa Vista da Aparecida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103107,41,'Bocaiúva do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103156,41,'Bom Jesus do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103206,41,'Bom Sucesso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103222,41,'Bom Sucesso do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103305,41,'Borrazópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103354,41,'Braganey');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103370,41,'Brasilândia do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103404,41,'Cafeara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103453,41,'Cafelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103479,41,'Cafezal do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103503,41,'Califórnia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103602,41,'Cambará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103701,41,'Cambé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103800,41,'Cambira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103909,41,'Campina da Lagoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4103958,41,'Campina do Simão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104006,41,'Campina Grande do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104055,41,'Campo Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104105,41,'Campo do Tenente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104204,41,'Campo Largo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104253,41,'Campo Magro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104303,41,'Campo Mourão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104402,41,'Cândido de Abreu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104428,41,'Candói');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104451,41,'Cantagalo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104501,41,'Capanema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104600,41,'Capitão Leônidas Marques');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104659,41,'Carambeí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104709,41,'Carlópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104808,41,'Cascavel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4104907,41,'Castro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105003,41,'Catanduvas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105102,41,'Centenário do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105201,41,'Cerro Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105300,41,'Céu Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105409,41,'Chopinzinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105508,41,'Cianorte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105607,41,'Cidade Gaúcha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105706,41,'Clevelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105805,41,'Colombo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4105904,41,'Colorado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106001,41,'Congonhinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106100,41,'Conselheiro Mairinck');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106209,41,'Contenda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106308,41,'Corbélia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106407,41,'Cornélio Procópio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106456,41,'Coronel domingos Soares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106506,41,'Coronel Vivida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106555,41,'Corumbataí do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106571,41,'Cruzeiro do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106605,41,'Cruzeiro do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106704,41,'Cruzeiro do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106803,41,'Cruz Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106852,41,'Cruzmaltina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4106902,41,'Curitiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107009,41,'Curiúva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107108,41,'Diamante do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107124,41,'Diamante do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107157,41,'Diamante Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107207,41,'dois Vizinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107256,41,'douradina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107306,41,'doutor Camargo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107405,41,'Enéas Marques');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107504,41,'Engenheiro Beltrão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107520,41,'Esperança Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107538,41,'Entre Rios do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107546,41,'Espigão Alto do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107553,41,'Farol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107603,41,'Faxinal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107652,41,'Fazenda Rio Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107702,41,'Fênix');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107736,41,'Fernandes Pinheiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107751,41,'Figueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107801,41,'Floraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107850,41,'Flor da Serra do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4107900,41,'Floresta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108007,41,'Florestópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108106,41,'Flórida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108205,41,'Formosa do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108304,41,'Foz do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108320,41,'Francisco Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108403,41,'Francisco Beltrão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108452,41,'Foz do Jordão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108502,41,'General Carneiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108551,41,'Godoy Moreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108601,41,'Goioerê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108650,41,'Goioxim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108700,41,'Grandes Rios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108809,41,'Guaíra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108908,41,'Guairaçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4108957,41,'Guamiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109005,41,'Guapirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109104,41,'Guaporema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109203,41,'Guaraci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109302,41,'Guaraniaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109401,41,'Guarapuava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109500,41,'Guaraqueçaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109609,41,'Guaratuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109658,41,'Honório Serpa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109708,41,'Ibaiti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109757,41,'Ibema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109807,41,'Ibiporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4109906,41,'Icaraíma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110003,41,'Iguaraçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110052,41,'Iguatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110078,41,'Imbaú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110102,41,'Imbituva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110201,41,'Inácio Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110300,41,'Inajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110409,41,'Indianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110508,41,'Ipiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110607,41,'Iporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110656,41,'Iracema do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110706,41,'Irati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110805,41,'Iretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110904,41,'Itaguajé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4110953,41,'Itaipulândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111001,41,'Itambaracá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111100,41,'Itambé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111209,41,'Itapejara Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111258,41,'Itaperuçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111308,41,'Itaúna do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111407,41,'Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111506,41,'Ivaiporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111555,41,'Ivaté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111605,41,'Ivatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111704,41,'Jaboti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111803,41,'Jacarezinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4111902,41,'Jaguapitã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112009,41,'Jaguariaíva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112108,41,'Jandaia do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112207,41,'Janiópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112306,41,'Japira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112405,41,'Japurá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112504,41,'Jardim Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112603,41,'Jardim Olinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112702,41,'Jataizinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112751,41,'Jesuítas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112801,41,'Joaquim Távora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112900,41,'Jundiaí do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4112959,41,'Juranda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113007,41,'Jussara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113106,41,'Kaloré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113205,41,'Lapa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113254,41,'Laranjal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113304,41,'Laranjeiras do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113403,41,'Leópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113429,41,'Lidianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113452,41,'Lindoeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113502,41,'Loanda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113601,41,'Lobato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113700,41,'Londrina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113734,41,'Luiziana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113759,41,'Lunardelli');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113809,41,'Lupionópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4113908,41,'Mallet');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114005,41,'Mamborê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114104,41,'Mandaguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114203,41,'Mandaguari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114302,41,'Mandirituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114351,41,'Manfrinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114401,41,'Mangueirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114500,41,'Manoel Ribas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114609,41,'Marechal Cândido Rondon');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114708,41,'Maria Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114807,41,'Marialva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4114906,41,'Marilândia do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115002,41,'Marilena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115101,41,'Mariluz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115200,41,'Maringá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115309,41,'Mariópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115358,41,'Maripá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115408,41,'Marmeleiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115457,41,'Marquinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115507,41,'Marumbi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115606,41,'Matelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115705,41,'Matinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115739,41,'Mato Rico');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115754,41,'Mauá da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115804,41,'Medianeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115853,41,'Mercedes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4115903,41,'Mirador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116000,41,'Miraselva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116059,41,'Missal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116109,41,'Moreira Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116208,41,'Morretes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116307,41,'Munhoz de Melo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116406,41,'Nossa Senhora das Graças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116505,41,'Nova Aliança do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116604,41,'Nova América da Colina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116703,41,'Nova Aurora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116802,41,'Nova Cantu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116901,41,'Nova Esperança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4116950,41,'Nova Esperança do Sudoeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117008,41,'Nova Fátima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117057,41,'Nova Laranjeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117107,41,'Nova Londrina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117206,41,'Nova Olímpia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117214,41,'Nova Santa Bárbara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117222,41,'Nova Santa Rosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117255,41,'Nova Prata do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117271,41,'Nova Tebas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117297,41,'Novo Itacolomi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117305,41,'Ortigueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117404,41,'Ourizona');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117453,41,'Ouro Verde do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117503,41,'Paiçandu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117602,41,'Palmas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117701,41,'Palmeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117800,41,'Palmital');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4117909,41,'Palotina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118006,41,'Paraíso do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118105,41,'Paranacity');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118204,41,'Paranaguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118303,41,'Paranapoema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118402,41,'Paranavaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118451,41,'Pato Bragado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118501,41,'Pato Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118600,41,'Paula Freitas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118709,41,'Paulo Frontin');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118808,41,'Peabiru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118857,41,'Perobal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4118907,41,'Pérola');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119004,41,'Pérola Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119103,41,'Piên');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119152,41,'Pinhais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119202,41,'Pinhalão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119251,41,'Pinhal de São Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119301,41,'Pinhão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119400,41,'Piraí do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119509,41,'Piraquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119608,41,'Pitanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119657,41,'Pitangueiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119707,41,'Planaltina do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119806,41,'Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119905,41,'Ponta Grossa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4119954,41,'Pontal do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120002,41,'Porecatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120101,41,'Porto Amazonas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120150,41,'Porto Barreiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120200,41,'Porto Rico');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120309,41,'Porto Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120333,41,'Prado Ferreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120358,41,'Pranchita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120408,41,'Presidente Castelo Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120507,41,'Primeiro de Maio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120606,41,'Prudentópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120655,41,'Quarto Centenário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120705,41,'Quatiguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120804,41,'Quatro Barras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120853,41,'Quatro Pontes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4120903,41,'Quedas do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121000,41,'Querência do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121109,41,'Quinta do Sol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121208,41,'Quitandinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121257,41,'Ramilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121307,41,'Rancho Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121356,41,'Rancho Alegre Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121406,41,'Realeza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121505,41,'Rebouças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121604,41,'Renascença');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121703,41,'Reserva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121752,41,'Reserva do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121802,41,'Ribeirão Claro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4121901,41,'Ribeirão do Pinhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122008,41,'Rio Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122107,41,'Rio Bom');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122156,41,'Rio Bonito do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122172,41,'Rio Branco do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122206,41,'Rio Branco do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122305,41,'Rio Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122404,41,'Rolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122503,41,'Roncador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122602,41,'Rondon');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122651,41,'Rosário do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122701,41,'Sabáudia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122800,41,'Salgado Filho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4122909,41,'Salto do Itararé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123006,41,'Salto do Lontra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123105,41,'Santa Amélia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123204,41,'Santa Cecília do Pavão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123303,41,'Santa Cruz de Monte Castelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123402,41,'Santa Fé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123501,41,'Santa Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123600,41,'Santa Inês');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123709,41,'Santa Isabel do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123808,41,'Santa Izabel do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123824,41,'Santa Lúcia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123857,41,'Santa Maria do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123907,41,'Santa Mariana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4123956,41,'Santa Mônica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124004,41,'Santana do Itararé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124020,41,'Santa Tereza do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124053,41,'Santa Terezinha de Itaipu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124103,41,'Santo Antônio da Platina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124202,41,'Santo Antônio do Caiuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124301,41,'Santo Antônio do Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124400,41,'Santo Antônio do Sudoeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124509,41,'Santo Inácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124608,41,'São Carlos do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124707,41,'São Jerônimo da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124806,41,'São João');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4124905,41,'São João do Caiuá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125001,41,'São João do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125100,41,'São João do Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125209,41,'São Jorge Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125308,41,'São Jorge do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125357,41,'São Jorge do Patrocínio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125407,41,'São José da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125456,41,'São José das Palmeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125506,41,'São José dos Pinhais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125555,41,'São Manoel do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125605,41,'São Mateus do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125704,41,'São Miguel do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125753,41,'São Pedro do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125803,41,'São Pedro do Ivaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4125902,41,'São Pedro do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126009,41,'São Sebastião da Amoreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126108,41,'São Tomé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126207,41,'Sapopema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126256,41,'Sarandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126272,41,'Saudade do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126306,41,'Sengés');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126355,41,'Serranópolis do Iguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126405,41,'Sertaneja');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126504,41,'Sertanópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126603,41,'Siqueira Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126652,41,'Sulina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126678,41,'Tamarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126702,41,'Tamboara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126801,41,'Tapejara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4126900,41,'Tapira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127007,41,'Teixeira Soares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127106,41,'Telêmaco Borba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127205,41,'Terra Boa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127304,41,'Terra Rica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127403,41,'Terra Roxa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127502,41,'Tibagi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127601,41,'Tijucas do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127700,41,'Toledo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127809,41,'Tomazina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127858,41,'Três Barras do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127882,41,'Tunas do Paraná');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127908,41,'Tuneiras do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127957,41,'Tupãssi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4127965,41,'Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128005,41,'Ubiratã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128104,41,'Umuarama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128203,41,'União da Vitória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128302,41,'Uniflor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128401,41,'Uraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128500,41,'Wenceslau Braz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128534,41,'Ventania');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128559,41,'Vera Cruz do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128609,41,'Verê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128625,41,'Alto Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128633,41,'doutor Ulysses');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128658,41,'Virmond');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128708,41,'Vitorino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4128807,41,'Xambrê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200051,42,'Abdon Batista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200101,42,'Abelardo Luz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200200,42,'Agrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200309,42,'Agronômica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200408,42,'Água doce');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200507,42,'Águas de Chapecó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200556,42,'Águas Frias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200606,42,'Águas Mornas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200705,42,'Alfredo Wagner');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200754,42,'Alto Bela Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200804,42,'Anchieta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4200903,42,'Angelina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201000,42,'Anita Garibaldi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201109,42,'Anitápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201208,42,'Antônio Carlos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201257,42,'Apiúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201273,42,'Arabutã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201307,42,'Araquari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201406,42,'Araranguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201505,42,'Armazém');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201604,42,'Arroio Trinta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201653,42,'Arvoredo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201703,42,'Ascurra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201802,42,'Atalanta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201901,42,'Aurora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4201950,42,'Balneário Arroio do Silva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202008,42,'Balneário Camboriú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202057,42,'Balneário Barra do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202073,42,'Balneário Gaivota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202081,42,'Bandeirante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202099,42,'Barra Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202107,42,'Barra Velha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202131,42,'Bela Vista do Toldo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202156,42,'Belmonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202206,42,'Benedito Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202305,42,'Biguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202404,42,'Blumenau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202438,42,'Bocaina do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202453,42,'Bombinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202503,42,'Bom Jardim da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202537,42,'Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202578,42,'Bom Jesus do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202602,42,'Bom Retiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202701,42,'Botuverá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202800,42,'Braço do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202859,42,'Braço do Trombudo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202875,42,'Brunópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4202909,42,'Brusque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203006,42,'Caçador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203105,42,'Caibi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203154,42,'Calmon');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203204,42,'Camboriú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203253,42,'Capão Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203303,42,'Campo Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203402,42,'Campo Belo do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203501,42,'Campo Erê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203600,42,'Campos Novos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203709,42,'Canelinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203808,42,'Canoinhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203907,42,'Capinzal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4203956,42,'Capivari de Baixo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204004,42,'Catanduvas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204103,42,'Caxambu do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204152,42,'Celso Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204178,42,'Cerro Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204194,42,'Chapadão do Lageado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204202,42,'Chapecó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204251,42,'Cocal do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204301,42,'Concórdia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204350,42,'Cordilheira Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204400,42,'Coronel Freitas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204459,42,'Coronel Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204509,42,'Corupá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204558,42,'Correia Pinto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204608,42,'Criciúma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204707,42,'Cunha Porã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204756,42,'Cunhataí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204806,42,'Curitibanos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4204905,42,'descanso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205001,42,'Dionísio Cerqueira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205100,42,'dona Emma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205159,42,'doutor Pedrinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205175,42,'Entre Rios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205191,42,'Ermo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205209,42,'Erval Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205308,42,'Faxinal dos Guedes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205357,42,'Flor do Sertão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205407,42,'Florianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205431,42,'Formosa do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205456,42,'Forquilhinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205506,42,'Fraiburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205555,42,'Frei Rogério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205605,42,'Galvão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205704,42,'Garopaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205803,42,'Garuva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4205902,42,'Gaspar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206009,42,'Governador Celso Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206108,42,'Grão Pará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206207,42,'Gravatal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206306,42,'Guabiruba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206405,42,'Guaraciaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206504,42,'Guaramirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206603,42,'Guarujá do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206652,42,'Guatambú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206702,42,'Herval Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206751,42,'Ibiam');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206801,42,'Ibicaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4206900,42,'Ibirama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207007,42,'Içara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207106,42,'Ilhota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207205,42,'Imaruí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207304,42,'Imbituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207403,42,'Imbuia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207502,42,'Indaial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207577,42,'Iomerê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207601,42,'Ipira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207650,42,'Iporã do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207684,42,'Ipuaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207700,42,'Ipumirim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207759,42,'Iraceminha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207809,42,'Irani');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207858,42,'Irati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4207908,42,'Irineópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208005,42,'Itá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208104,42,'Itaiópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208203,42,'Itajaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208302,42,'Itapema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208401,42,'Itapiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208450,42,'Itapoá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208500,42,'Ituporanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208609,42,'Jaborá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208708,42,'Jacinto Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208807,42,'Jaguaruna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208906,42,'Jaraguá do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4208955,42,'Jardinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209003,42,'Joaçaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209102,42,'Joinville');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209151,42,'José Boiteux');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209177,42,'Jupiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209201,42,'Lacerdópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209300,42,'Lages');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209409,42,'Laguna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209458,42,'Lajeado Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209508,42,'Laurentino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209607,42,'Lauro Muller');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209706,42,'Lebon Régis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209805,42,'Leoberto Leal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209854,42,'Lindóia do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4209904,42,'Lontras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210001,42,'Luiz Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210035,42,'Luzerna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210050,42,'Macieira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210100,42,'Mafra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210209,42,'Major Gercino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210308,42,'Major Vieira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210407,42,'Maracajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210506,42,'Maravilha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210555,42,'Marema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210605,42,'Massaranduba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210704,42,'Matos Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210803,42,'Meleiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210852,42,'Mirim doce');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4210902,42,'Modelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211009,42,'Mondaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211058,42,'Monte Carlo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211108,42,'Monte Castelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211207,42,'Morro da Fumaça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211256,42,'Morro Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211306,42,'Navegantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211405,42,'Nova Erechim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211454,42,'Nova Itaberaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211504,42,'Nova Trento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211603,42,'Nova Veneza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211652,42,'Novo Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211702,42,'Orleans');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211751,42,'Otacílio Costa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211801,42,'Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211850,42,'Ouro Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211876,42,'Paial');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211892,42,'Painel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4211900,42,'Palhoça');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212007,42,'Palma Sola');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212056,42,'Palmeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212106,42,'Palmitos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212205,42,'Papanduva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212239,42,'Paraíso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212254,42,'Passo de Torres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212270,42,'Passos Maia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212304,42,'Paulo Lopes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212403,42,'Pedras Grandes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212502,42,'Penha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212601,42,'Peritiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212650,42,'Pescaria Brava');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212700,42,'Petrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212809,42,'Balneário Piçarras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4212908,42,'Pinhalzinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213005,42,'Pinheiro Preto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213104,42,'Piratuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213153,42,'Planalto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213203,42,'Pomerode');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213302,42,'Ponte Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213351,42,'Ponte Alta do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213401,42,'Ponte Serrada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213500,42,'Porto Belo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213609,42,'Porto União');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213708,42,'Pouso Redondo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213807,42,'Praia Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4213906,42,'Presidente Castello Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214003,42,'Presidente Getúlio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214102,42,'Presidente Nereu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214151,42,'Princesa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214201,42,'Quilombo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214300,42,'Rancho Queimado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214409,42,'Rio das Antas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214508,42,'Rio do Campo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214607,42,'Rio do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214706,42,'Rio dos Cedros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214805,42,'Rio do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4214904,42,'Rio Fortuna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215000,42,'Rio Negrinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215059,42,'Rio Rufino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215075,42,'Riqueza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215109,42,'Rodeio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215208,42,'Romelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215307,42,'Salete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215356,42,'Saltinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215406,42,'Salto Veloso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215455,42,'Sangão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215505,42,'Santa Cecília');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215554,42,'Santa Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215604,42,'Santa Rosa de Lima');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215653,42,'Santa Rosa do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215679,42,'Santa Terezinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215687,42,'Santa Terezinha do Progresso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215695,42,'Santiago do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215703,42,'Santo Amaro da Imperatriz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215752,42,'São Bernardino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215802,42,'São Bento do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4215901,42,'São Bonifácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216008,42,'São Carlos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216057,42,'São Cristovão do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216107,42,'São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216206,42,'São Francisco do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216255,42,'São João do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216305,42,'São João Batista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216354,42,'São João do Itaperiú');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216404,42,'São João do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216503,42,'São Joaquim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216602,42,'São José');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216701,42,'São José do Cedro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216800,42,'São José do Cerrito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4216909,42,'São Lourenço do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217006,42,'São Ludgero');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217105,42,'São Martinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217154,42,'São Miguel da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217204,42,'São Miguel do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217253,42,'São Pedro de Alcântara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217303,42,'Saudades');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217402,42,'Schroeder');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217501,42,'Seara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217550,42,'Serra Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217600,42,'Siderópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217709,42,'Sombrio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217758,42,'Sul Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217808,42,'Taió');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217907,42,'Tangará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4217956,42,'Tigrinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218004,42,'Tijucas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218103,42,'Timbé do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218202,42,'Timbó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218251,42,'Timbó Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218301,42,'Três Barras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218350,42,'Treviso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218400,42,'Treze de Maio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218509,42,'Treze Tílias');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218608,42,'Trombudo Central');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218707,42,'Tubarão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218756,42,'Tunápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218806,42,'Turvo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218855,42,'União do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218905,42,'Urubici');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4218954,42,'Urupema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219002,42,'Urussanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219101,42,'Vargeão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219150,42,'Vargem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219176,42,'Vargem Bonita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219200,42,'Vidal Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219309,42,'Videira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219358,42,'Vitor Meireles');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219408,42,'Witmarsum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219507,42,'Xanxerê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219606,42,'Xavantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219705,42,'Xaxim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4219853,42,'Zortéa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4220000,42,'Balneário Rincão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300034,43,'Aceguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300059,43,'Água Santa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300109,43,'Agudo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300208,43,'Ajuricaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300307,43,'Alecrim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300406,43,'Alegrete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300455,43,'Alegria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300471,43,'Almirante Tamandaré do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300505,43,'Alpestre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300554,43,'Alto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300570,43,'Alto Feliz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300604,43,'Alvorada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300638,43,'Amaral Ferrador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300646,43,'Ametista do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300661,43,'André da Rocha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300703,43,'Anta Gorda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300802,43,'Antônio Prado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300851,43,'Arambaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300877,43,'Araricá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4300901,43,'Aratiba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301008,43,'Arroio do Meio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301057,43,'Arroio do Sal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301073,43,'Arroio do Padre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301107,43,'Arroio dos Ratos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301206,43,'Arroio do Tigre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301305,43,'Arroio Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301404,43,'Arvorezinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301503,43,'Augusto Pestana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301552,43,'Áurea');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301602,43,'Bagé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301636,43,'Balneário Pinhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301651,43,'Barão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301701,43,'Barão de Cotegipe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301750,43,'Barão do Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301800,43,'Barracão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301859,43,'Barra do Guarita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301875,43,'Barra do Quaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301909,43,'Barra do Ribeiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301925,43,'Barra do Rio Azul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4301958,43,'Barra Funda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302006,43,'Barros Cassal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302055,43,'Benjamin Constant do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302105,43,'Bento Gonçalves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302154,43,'Boa Vista das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302204,43,'Boa Vista do Buricá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302220,43,'Boa Vista do Cadeado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302238,43,'Boa Vista do Incra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302253,43,'Boa Vista do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302303,43,'Bom Jesus');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302352,43,'Bom Princípio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302378,43,'Bom Progresso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302402,43,'Bom Retiro do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302451,43,'Boqueirão do Leão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302501,43,'Bossoroca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302584,43,'Bozano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302600,43,'Braga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302659,43,'Brochier');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302709,43,'Butiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302808,43,'Caçapava do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4302907,43,'Cacequi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303004,43,'Cachoeira do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303103,43,'Cachoeirinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303202,43,'Cacique doble');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303301,43,'Caibaté');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303400,43,'Caiçara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303509,43,'Camaquã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303558,43,'Camargo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303608,43,'Cambará do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303673,43,'Campestre da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303707,43,'Campina das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303806,43,'Campinas do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4303905,43,'Campo Bom');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304002,43,'Campo Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304101,43,'Campos Borges');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304200,43,'Candelária');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304309,43,'Cândido Godói');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304358,43,'Candiota');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304408,43,'Canela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304507,43,'Canguçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304606,43,'Canoas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304614,43,'Canudos do Vale');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304622,43,'Capão Bonito do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304630,43,'Capão da Canoa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304655,43,'Capão do Cipó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304663,43,'Capão do Leão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304671,43,'Capivari do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304689,43,'Capela de Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304697,43,'Capitão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304705,43,'Carazinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304713,43,'Caraá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304804,43,'Carlos Barbosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304853,43,'Carlos Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304903,43,'Casca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4304952,43,'Caseiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305009,43,'Catuípe');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305108,43,'Caxias do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305116,43,'Centenário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305124,43,'Cerrito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305132,43,'Cerro Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305157,43,'Cerro Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305173,43,'Cerro Grande do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305207,43,'Cerro Largo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305306,43,'Chapada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305355,43,'Charqueadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305371,43,'Charrua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305405,43,'Chiapetta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305439,43,'Chuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305447,43,'Chuvisca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305454,43,'Cidreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305504,43,'Ciríaco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305587,43,'Colinas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305603,43,'Colorado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305702,43,'Condor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305801,43,'Constantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305835,43,'Coqueiro Baixo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305850,43,'Coqueiros do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305871,43,'Coronel Barros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305900,43,'Coronel Bicaco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305934,43,'Coronel Pilar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305959,43,'Cotiporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4305975,43,'Coxilha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306007,43,'Crissiumal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306056,43,'Cristal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306072,43,'Cristal do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306106,43,'Cruz Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306130,43,'Cruzaltense');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306205,43,'Cruzeiro do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306304,43,'david Canabarro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306320,43,'derrubadas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306353,43,'dezesseis de Novembro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306379,43,'Dilermando de Aguiar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306403,43,'dois Irmãos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306429,43,'dois Irmãos das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306452,43,'dois Lajeados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306502,43,'dom Feliciano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306551,43,'dom Pedro de Alcântara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306601,43,'dom Pedrito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306700,43,'dona Francisca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306734,43,'doutor Maurício Cardoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306759,43,'doutor Ricardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306767,43,'Eldorado do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306809,43,'Encantado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306908,43,'Encruzilhada do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306924,43,'Engenho Velho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306932,43,'Entre-Ijuís');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306957,43,'Entre Rios do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4306973,43,'Erebango');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307005,43,'Erechim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307054,43,'Ernestina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307104,43,'Herval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307203,43,'Erval Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307302,43,'Erval Seco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307401,43,'Esmeralda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307450,43,'Esperança do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307500,43,'Espumoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307559,43,'Estação');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307609,43,'Estância Velha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307708,43,'Esteio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307807,43,'Estrela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307815,43,'Estrela Velha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307831,43,'Eugênio de Castro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307864,43,'Fagundes Varela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4307906,43,'Farroupilha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308003,43,'Faxinal do Soturno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308052,43,'Faxinalzinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308078,43,'Fazenda Vilanova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308102,43,'Feliz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308201,43,'Flores da Cunha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308250,43,'Floriano Peixoto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308300,43,'Fontoura Xavier');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308409,43,'Formigueiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308433,43,'Forquetinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308458,43,'Fortaleza dos Valos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308508,43,'Frederico Westphalen');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308607,43,'Garibaldi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308656,43,'Garruchos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308706,43,'Gaurama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308805,43,'General Câmara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308854,43,'Gentil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4308904,43,'Getúlio Vargas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309001,43,'Giruá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309050,43,'Glorinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309100,43,'Gramado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309126,43,'Gramado dos Loureiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309159,43,'Gramado Xavier');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309209,43,'Gravataí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309258,43,'Guabiju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309308,43,'Guaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309407,43,'Guaporé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309506,43,'Guarani das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309555,43,'Harmonia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309571,43,'Herveiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309605,43,'Horizontina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309654,43,'Hulha Negra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309704,43,'Humaitá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309753,43,'Ibarama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309803,43,'Ibiaçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309902,43,'Ibiraiaras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4309951,43,'Ibirapuitã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310009,43,'Ibirubá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310108,43,'Igrejinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310207,43,'Ijuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310306,43,'Ilópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310330,43,'Imbé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310363,43,'Imigrante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310405,43,'Independência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310413,43,'Inhacorá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310439,43,'Ipê');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310462,43,'Ipiranga do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310504,43,'Iraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310538,43,'Itaara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310553,43,'Itacurubi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310579,43,'Itapuca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310603,43,'Itaqui');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310652,43,'Itati');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310702,43,'Itatiba do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310751,43,'Ivorá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310801,43,'Ivoti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310850,43,'Jaboticaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310876,43,'Jacuizinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4310900,43,'Jacutinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311007,43,'Jaguarão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311106,43,'Jaguari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311122,43,'Jaquirana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311130,43,'Jari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311155,43,'Jóia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311205,43,'Júlio de Castilhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311239,43,'Lagoa Bonita do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311254,43,'Lagoão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311270,43,'Lagoa dos Três Cantos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311304,43,'Lagoa Vermelha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311403,43,'Lajeado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311429,43,'Lajeado do Bugre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311502,43,'Lavras do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311601,43,'Liberato Salzano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311627,43,'Lindolfo Collor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311643,43,'Linha Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311700,43,'Machadinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311718,43,'Maçambará');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311734,43,'Mampituba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311759,43,'Manoel Viana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311775,43,'Maquiné');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311791,43,'Maratá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311809,43,'Marau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311908,43,'Marcelino Ramos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4311981,43,'Mariana Pimentel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312005,43,'Mariano Moro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312054,43,'Marques de Souza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312104,43,'Mata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312138,43,'Mato Castelhano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312153,43,'Mato Leitão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312179,43,'Mato Queimado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312203,43,'Maximiliano de Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312252,43,'Minas do Leão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312302,43,'Miraguaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312351,43,'Montauri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312377,43,'Monte Alegre dos Campos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312385,43,'Monte Belo do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312401,43,'Montenegro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312427,43,'Mormaço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312443,43,'Morrinhos do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312450,43,'Morro Redondo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312476,43,'Morro Reuter');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312500,43,'Mostardas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312609,43,'Muçum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312617,43,'Muitos Capões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312625,43,'Muliterno');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312658,43,'Não-Me-Toque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312674,43,'Nicolau Vergueiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312708,43,'Nonoai');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312757,43,'Nova Alvorada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312807,43,'Nova Araçá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312906,43,'Nova Bassano');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4312955,43,'Nova Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313003,43,'Nova Bréscia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313011,43,'Nova Candelária');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313037,43,'Nova Esperança do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313060,43,'Nova Hartz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313086,43,'Nova Pádua');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313102,43,'Nova Palma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313201,43,'Nova Petrópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313300,43,'Nova Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313334,43,'Nova Ramada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313359,43,'Nova Roma do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313375,43,'Nova Santa Rita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313391,43,'Novo Cabrais');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313409,43,'Novo Hamburgo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313425,43,'Novo Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313441,43,'Novo Tiradentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313466,43,'Novo Xingu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313490,43,'Novo Barreiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313508,43,'Osório');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313607,43,'Paim Filho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313656,43,'Palmares do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313706,43,'Palmeira das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313805,43,'Palmitinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313904,43,'Panambi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4313953,43,'Pantano Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314001,43,'Paraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314027,43,'Paraíso do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314035,43,'Pareci Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314050,43,'Parobé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314068,43,'Passa Sete');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314076,43,'Passo do Sobrado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314100,43,'Passo Fundo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314134,43,'Paulo Bento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314159,43,'Paverama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314175,43,'Pedras Altas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314209,43,'Pedro Osório');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314308,43,'Pejuçara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314407,43,'Pelotas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314423,43,'Picada Café');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314456,43,'Pinhal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314464,43,'Pinhal da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314472,43,'Pinhal Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314498,43,'Pinheirinho do Vale');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314506,43,'Pinheiro Machado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314548,43,'Pinto Bandeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314555,43,'Pirapó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314605,43,'Piratini');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314704,43,'Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314753,43,'Poço das Antas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314779,43,'Pontão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314787,43,'Ponte Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314803,43,'Portão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4314902,43,'Porto Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315008,43,'Porto Lucena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315057,43,'Porto Mauá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315073,43,'Porto Vera Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315107,43,'Porto Xavier');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315131,43,'Pouso Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315149,43,'Presidente Lucena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315156,43,'Progresso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315172,43,'Protásio Alves');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315206,43,'Putinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315305,43,'Quaraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315313,43,'Quatro Irmãos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315321,43,'Quevedos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315354,43,'Quinze de Novembro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315404,43,'Redentora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315453,43,'Relvado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315503,43,'Restinga Seca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315552,43,'Rio dos Índios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315602,43,'Rio Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315701,43,'Rio Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315750,43,'Riozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315800,43,'Roca Sales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315909,43,'Rodeio Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4315958,43,'Rolador');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316006,43,'Rolante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316105,43,'Ronda Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316204,43,'Rondinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316303,43,'Roque Gonzales');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316402,43,'Rosário do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316428,43,'Sagrada Família');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316436,43,'Saldanha Marinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316451,43,'Salto do Jacuí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316477,43,'Salvador das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316501,43,'Salvador do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316600,43,'Sananduva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316709,43,'Santa Bárbara do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316733,43,'Santa Cecília do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316758,43,'Santa Clara do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316808,43,'Santa Cruz do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316907,43,'Santa Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316956,43,'Santa Maria do Herval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4316972,43,'Santa Margarida do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317004,43,'Santana da Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317103,43,'Santana do Livramento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317202,43,'Santa Rosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317251,43,'Santa Tereza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317301,43,'Santa Vitória do Palmar');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317400,43,'Santiago');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317509,43,'Santo Ângelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317558,43,'Santo Antônio do Palma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317608,43,'Santo Antônio da Patrulha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317707,43,'Santo Antônio das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317756,43,'Santo Antônio do Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317806,43,'Santo Augusto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317905,43,'Santo Cristo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4317954,43,'Santo Expedito do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318002,43,'São Borja');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318051,43,'São domingos do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318101,43,'São Francisco de Assis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318200,43,'São Francisco de Paula');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318309,43,'São Gabriel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318408,43,'São Jerônimo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318424,43,'São João da Urtiga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318432,43,'São João do Polêsine');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318440,43,'São Jorge');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318457,43,'São José das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318465,43,'São José do Herval');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318481,43,'São José do Hortêncio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318499,43,'São José do Inhacorá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318507,43,'São José do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318606,43,'São José do Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318614,43,'São José do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318622,43,'São José dos Ausentes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318705,43,'São Leopoldo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318804,43,'São Lourenço do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4318903,43,'São Luiz Gonzaga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319000,43,'São Marcos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319109,43,'São Martinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319125,43,'São Martinho da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319158,43,'São Miguel das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319208,43,'São Nicolau');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319307,43,'São Paulo das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319356,43,'São Pedro da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319364,43,'São Pedro das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319372,43,'São Pedro do Butiá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319406,43,'São Pedro do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319505,43,'São Sebastião do Caí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319604,43,'São Sepé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319703,43,'São Valentim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319711,43,'São Valentim do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319737,43,'São Valério do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319752,43,'São Vendelino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319802,43,'São Vicente do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4319901,43,'Sapiranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320008,43,'Sapucaia do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320107,43,'Sarandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320206,43,'Seberi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320230,43,'Sede Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320263,43,'Segredo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320305,43,'Selbach');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320321,43,'Senador Salgado Filho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320354,43,'Sentinela do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320404,43,'Serafina Corrêa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320453,43,'Sério');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320503,43,'Sertão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320552,43,'Sertão Santana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320578,43,'Sete de Setembro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320602,43,'Severiano de Almeida');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320651,43,'Silveira Martins');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320677,43,'Sinimbu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320701,43,'Sobradinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320800,43,'Soledade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320859,43,'Tabaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4320909,43,'Tapejara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321006,43,'Tapera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321105,43,'Tapes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321204,43,'Taquara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321303,43,'Taquari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321329,43,'Taquaruçu do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321352,43,'Tavares');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321402,43,'Tenente Portela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321436,43,'Terra de Areia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321451,43,'Teutônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321469,43,'Tio Hugo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321477,43,'Tiradentes do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321493,43,'Toropi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321501,43,'Torres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321600,43,'Tramandaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321626,43,'Travesseiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321634,43,'Três Arroios');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321667,43,'Três Cachoeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321709,43,'Três Coroas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321808,43,'Três de Maio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321832,43,'Três Forquilhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321857,43,'Três Palmeiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321907,43,'Três Passos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4321956,43,'Trindade do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322004,43,'Triunfo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322103,43,'Tucunduva');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322152,43,'Tunas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322186,43,'Tupanci do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322202,43,'Tupanciretã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322251,43,'Tupandi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322301,43,'Tuparendi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322327,43,'Turuçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322343,43,'Ubiretama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322350,43,'União da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322376,43,'Unistalda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322400,43,'Uruguaiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322509,43,'Vacaria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322525,43,'Vale Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322533,43,'Vale do Sol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322541,43,'Vale Real');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322558,43,'Vanini');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322608,43,'Venâncio Aires');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322707,43,'Vera Cruz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322806,43,'Veranópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322855,43,'Vespasiano Correa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4322905,43,'Viadutos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323002,43,'Viamão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323101,43,'Vicente Dutra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323200,43,'Victor Graeff');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323309,43,'Vila Flores');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323358,43,'Vila Lângaro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323408,43,'Vila Maria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323457,43,'Vila Nova do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323507,43,'Vista Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323606,43,'Vista Alegre do Prata');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323705,43,'Vista Gaúcha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323754,43,'Vitória das Missões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323770,43,'Westfalia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(4323804,43,'Xangri-Lá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000203,50,'Água Clara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000252,50,'Alcinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000609,50,'Amambai');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000708,50,'Anastácio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000807,50,'Anaurilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000856,50,'Angélica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5000906,50,'Antônio João');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5001003,50,'Aparecida do Taboado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5001102,50,'Aquidauana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5001243,50,'Aral Moreira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5001508,50,'Bandeirantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5001904,50,'Bataguassu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002001,50,'Batayporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002100,50,'Bela Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002159,50,'Bodoquena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002209,50,'Bonito');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002308,50,'Brasilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002407,50,'Caarapó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002605,50,'Camapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002704,50,'Campo Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002803,50,'Caracol');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002902,50,'Cassilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5002951,50,'Chapadão do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003108,50,'Corguinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003157,50,'Coronel Sapucaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003207,50,'Corumbá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003256,50,'Costa Rica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003306,50,'Coxim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003454,50,'deodápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003488,50,'dois Irmãos do Buriti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003504,50,'douradina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003702,50,'dourados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003751,50,'Eldorado');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003801,50,'Fátima do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5003900,50,'Figueirão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004007,50,'Glória de dourados');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004106,50,'Guia Lopes da Laguna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004304,50,'Iguatemi');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004403,50,'Inocência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004502,50,'Itaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004601,50,'Itaquiraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004700,50,'Ivinhema');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004809,50,'Japorã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5004908,50,'Jaraguari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005004,50,'Jardim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005103,50,'Jateí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005152,50,'Juti');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005202,50,'Ladário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005251,50,'Laguna Carapã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005400,50,'Maracaju');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005608,50,'Miranda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005681,50,'Mundo Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005707,50,'Naviraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5005806,50,'Nioaque');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006002,50,'Nova Alvorada do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006200,50,'Nova Andradina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006259,50,'Novo Horizonte do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006275,50,'Paraíso das Águas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006309,50,'Paranaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006358,50,'Paranhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006408,50,'Pedro Gomes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006606,50,'Ponta Porã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5006903,50,'Porto Murtinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007109,50,'Ribas do Rio Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007208,50,'Rio Brilhante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007307,50,'Rio Negro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007406,50,'Rio Verde de Mato Grosso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007505,50,'Rochedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007554,50,'Santa Rita do Pardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007695,50,'São Gabriel do Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007703,50,'Sete Quedas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007802,50,'Selvíria');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007901,50,'Sidrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007935,50,'Sonora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007950,50,'Tacuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5007976,50,'Taquarussu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5008008,50,'Terenos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5008305,50,'Três Lagoas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5008404,50,'Vicentina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100102,51,'Acorizal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100201,51,'Água Boa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100250,51,'Alta Floresta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100300,51,'Alto Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100359,51,'Alto Boa Vista');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100409,51,'Alto Garças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100508,51,'Alto Paraguai');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100607,51,'Alto Taquari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5100805,51,'Apiacás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101001,51,'Araguaiana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101209,51,'Araguainha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101258,51,'Araputanga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101308,51,'Arenápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101407,51,'Aripuanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101605,51,'Barão de Melgaço');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101704,51,'Barra do Bugres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101803,51,'Barra do Garças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101852,51,'Bom Jesus do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5101902,51,'Brasnorte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102504,51,'Cáceres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102603,51,'Campinápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102637,51,'Campo Novo do Parecis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102678,51,'Campo Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102686,51,'Campos de Júlio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102694,51,'Canabrava do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102702,51,'Canarana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102793,51,'Carlinda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5102850,51,'Castanheira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103007,51,'Chapada dos Guimarães');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103056,51,'Cláudia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103106,51,'Cocalinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103205,51,'Colíder');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103254,51,'Colniza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103304,51,'Comodoro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103353,51,'Confresa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103361,51,'Conquista Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103379,51,'Cotriguaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103403,51,'Cuiabá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103437,51,'Curvelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103452,51,'denise');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103502,51,'Diamantino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103601,51,'dom Aquino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103700,51,'Feliz Natal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103809,51,'Figueirópolis Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103858,51,'Gaúcha do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103908,51,'General Carneiro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5103957,51,'Glória Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104104,51,'Guarantã do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104203,51,'Guiratinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104500,51,'Indiavaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104526,51,'Ipiranga do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104542,51,'Itanhangá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104559,51,'Itaúba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104609,51,'Itiquira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104807,51,'Jaciara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5104906,51,'Jangada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105002,51,'Jauru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105101,51,'Juara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105150,51,'Juína');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105176,51,'Juruena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105200,51,'Juscimeira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105234,51,'Lambari Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105259,51,'Lucas do Rio Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105309,51,'Luciara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105507,51,'Vila Bela da Santíssima Trindade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105580,51,'Marcelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105606,51,'Matupá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105622,51,'Mirassol Doeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5105903,51,'Nobres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106000,51,'Nortelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106109,51,'Nossa Senhora do Livramento');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106158,51,'Nova Bandeirantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106174,51,'Nova Nazaré');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106182,51,'Nova Lacerda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106190,51,'Nova Santa Helena');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106208,51,'Nova Brasilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106216,51,'Nova Canaã do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106224,51,'Nova Mutum');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106232,51,'Nova Olímpia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106240,51,'Nova Ubiratã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106257,51,'Nova Xavantina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106265,51,'Novo Mundo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106273,51,'Novo Horizonte do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106281,51,'Novo São Joaquim');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106299,51,'Paranaíta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106307,51,'Paranatinga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106315,51,'Novo Santo Antônio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106372,51,'Pedra Preta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106422,51,'Peixoto de Azevedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106455,51,'Planalto da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106505,51,'Poconé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106653,51,'Pontal do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106703,51,'Ponte Branca');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106752,51,'Pontes E Lacerda');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106778,51,'Porto Alegre do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106802,51,'Porto dos Gaúchos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106828,51,'Porto Esperidião');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5106851,51,'Porto Estrela');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107008,51,'Poxoréu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107040,51,'Primavera do Leste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107065,51,'Querência');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107107,51,'São José dos Quatro Marcos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107156,51,'Reserva do Cabaçal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107180,51,'Ribeirão Cascalheira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107198,51,'Ribeirãozinho');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107206,51,'Rio Branco');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107248,51,'Santa Carmem');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107263,51,'Santo Afonso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107297,51,'São José do Povo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107305,51,'São José do Rio Claro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107354,51,'São José do Xingu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107404,51,'São Pedro da Cipa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107578,51,'Rondolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107602,51,'Rondonópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107701,51,'Rosário Oeste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107743,51,'Santa Cruz do Xingu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107750,51,'Salto do Céu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107768,51,'Santa Rita do Trivelato');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107776,51,'Santa Terezinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107792,51,'Santo Antônio do Leste');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107800,51,'Santo Antônio do Leverger');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107859,51,'São Félix do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107875,51,'Sapezal');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107883,51,'Serra Nova dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107909,51,'Sinop');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107925,51,'Sorriso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107941,51,'Tabaporã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5107958,51,'Tangará da Serra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108006,51,'Tapurah');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108055,51,'Terra Nova do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108105,51,'Tesouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108204,51,'Torixoréu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108303,51,'União do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108352,51,'Vale de São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108402,51,'Várzea Grande');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108501,51,'Vera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108600,51,'Vila Rica');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108808,51,'Nova Guarita');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108857,51,'Nova Marilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108907,51,'Nova Maringá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5108956,51,'Nova Monte Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200050,52,'Abadia de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200100,52,'Abadiânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200134,52,'Acreúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200159,52,'Adelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200175,52,'Água Fria de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200209,52,'Água Limpa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200258,52,'Águas Lindas de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200308,52,'Alexânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200506,52,'Aloândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200555,52,'Alto Horizonte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200605,52,'Alto Paraíso de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200803,52,'Alvorada do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200829,52,'Amaralina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200852,52,'Americano do Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5200902,52,'Amorinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201108,52,'Anápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201207,52,'Anhanguera');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201306,52,'Anicuns');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201405,52,'Aparecida de Goiânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201454,52,'Aparecida do Rio doce');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201504,52,'Aporé');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201603,52,'Araçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201702,52,'Aragarças');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5201801,52,'Aragoiânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5202155,52,'Araguapaz');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5202353,52,'Arenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5202502,52,'Aruanã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5202601,52,'Aurilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5202809,52,'Avelinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203104,52,'Baliza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203203,52,'Barro Alto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203302,52,'Bela Vista de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203401,52,'Bom Jardim de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203500,52,'Bom Jesus de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203559,52,'Bonfinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203575,52,'Bonópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203609,52,'Brazabrantes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203807,52,'Britânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203906,52,'Buriti Alegre');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203939,52,'Buriti de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5203962,52,'Buritinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204003,52,'Cabeceiras');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204102,52,'Cachoeira Alta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204201,52,'Cachoeira de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204250,52,'Cachoeira dourada');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204300,52,'Caçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204409,52,'Caiapônia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204508,52,'Caldas Novas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204557,52,'Caldazinha');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204607,52,'Campestre de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204656,52,'Campinaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204706,52,'Campinorte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204805,52,'Campo Alegre de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204854,52,'Campo Limpo de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204904,52,'Campos Belos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5204953,52,'Campos Verdes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205000,52,'Carmo do Rio Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205059,52,'Castelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205109,52,'Catalão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205208,52,'Caturaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205307,52,'Cavalcante');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205406,52,'Ceres');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205455,52,'Cezarina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205471,52,'Chapadão do Céu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205497,52,'Cidade Ocidental');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205513,52,'Cocalzinho de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205521,52,'Colinas do Sul');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205703,52,'Córrego do Ouro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205802,52,'Corumbá de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5205901,52,'Corumbaíba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206206,52,'Cristalina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206305,52,'Cristianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206404,52,'Crixás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206503,52,'Cromínia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206602,52,'Cumari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206701,52,'damianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206800,52,'damolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5206909,52,'davinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207105,52,'Diorama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207253,52,'doverlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207352,52,'Edealina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207402,52,'Edéia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207501,52,'Estrela do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207535,52,'Faina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207600,52,'Fazenda Nova');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207808,52,'Firminópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5207907,52,'Flores de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208004,52,'Formosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208103,52,'Formoso');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208152,52,'Gameleira de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208301,52,'Divinópolis de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208400,52,'Goianápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208509,52,'Goiandira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208608,52,'Goianésia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208707,52,'Goiânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208806,52,'Goianira');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5208905,52,'Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209101,52,'Goiatuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209150,52,'Gouvelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209200,52,'Guapó');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209291,52,'Guaraíta');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209408,52,'Guarani de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209457,52,'Guarinos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209606,52,'Heitoraí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209705,52,'Hidrolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209804,52,'Hidrolina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209903,52,'Iaciara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209937,52,'Inaciolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5209952,52,'Indiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210000,52,'Inhumas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210109,52,'Ipameri');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210158,52,'Ipiranga de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210208,52,'Iporá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210307,52,'Israelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210406,52,'Itaberaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210562,52,'Itaguari');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210604,52,'Itaguaru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210802,52,'Itajá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5210901,52,'Itapaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211008,52,'Itapirapuã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211206,52,'Itapuranga');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211305,52,'Itarumã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211404,52,'Itauçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211503,52,'Itumbiara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211602,52,'Ivolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211701,52,'Jandaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211800,52,'Jaraguá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5211909,52,'Jataí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212006,52,'Jaupaci');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212055,52,'Jesúpolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212105,52,'Joviânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212204,52,'Jussara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212253,52,'Lagoa Santa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212303,52,'Leopoldo de Bulhões');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212501,52,'Luziânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212600,52,'Mairipotaba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212709,52,'Mambaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212808,52,'Mara Rosa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212907,52,'Marzagão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5212956,52,'Matrinchã');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213004,52,'Maurilândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213053,52,'Mimoso de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213087,52,'Minaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213103,52,'Mineiros');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213400,52,'Moiporá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213509,52,'Monte Alegre de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213707,52,'Montes Claros de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213756,52,'Montividiu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213772,52,'Montividiu do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213806,52,'Morrinhos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213855,52,'Morro Agudo de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5213905,52,'Mossâmedes');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214002,52,'Mozarlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214051,52,'Mundo Novo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214101,52,'Mutunópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214408,52,'Nazário');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214507,52,'Nerópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214606,52,'Niquelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214705,52,'Nova América');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214804,52,'Nova Aurora');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214838,52,'Nova Crixás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214861,52,'Nova Glória');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214879,52,'Nova Iguaçu de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5214903,52,'Nova Roma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215009,52,'Nova Veneza');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215207,52,'Novo Brasil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215231,52,'Novo Gama');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215256,52,'Novo Planalto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215306,52,'Orizona');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215405,52,'Ouro Verde de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215504,52,'Ouvidor');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215603,52,'Padre Bernardo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215652,52,'Palestina de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215702,52,'Palmeiras de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215801,52,'Palmelo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5215900,52,'Palminópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216007,52,'Panamá');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216304,52,'Paranaiguara');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216403,52,'Paraúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216452,52,'Perolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216809,52,'Petrolina de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5216908,52,'Pilar de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217104,52,'Piracanjuba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217203,52,'Piranhas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217302,52,'Pirenópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217401,52,'Pires do Rio');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217609,52,'Planaltina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5217708,52,'Pontalina');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218003,52,'Porangatu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218052,52,'Porteirão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218102,52,'Portelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218300,52,'Posse');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218391,52,'Professor Jamil');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218508,52,'Quirinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218607,52,'Rialma');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218706,52,'Rianápolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218789,52,'Rio Quente');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218805,52,'Rio Verde');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5218904,52,'Rubiataba');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219001,52,'Sanclerlândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219100,52,'Santa Bárbara de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219209,52,'Santa Cruz de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219258,52,'Santa Fé de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219308,52,'Santa Helena de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219357,52,'Santa Isabel');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219407,52,'Santa Rita do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219456,52,'Santa Rita do Novo destino');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219506,52,'Santa Rosa de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219605,52,'Santa Tereza de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219704,52,'Santa Terezinha de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219712,52,'Santo Antônio da Barra');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219738,52,'Santo Antônio de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219753,52,'Santo Antônio do descoberto');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219803,52,'São domingos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5219902,52,'São Francisco de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220009,52,'São João Daliança');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220058,52,'São João da Paraúna');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220108,52,'São Luís de Montes Belos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220157,52,'São Luíz do Norte');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220207,52,'São Miguel do Araguaia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220264,52,'São Miguel do Passa Quatro');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220280,52,'São Patrício');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220405,52,'São Simão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220454,52,'Senador Canedo');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220504,52,'Serranópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220603,52,'Silvânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220686,52,'Simolândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5220702,52,'Sítio Dabadia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221007,52,'Taquaral de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221080,52,'Teresina de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221197,52,'Terezópolis de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221304,52,'Três Ranchos');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221403,52,'Trindade');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221452,52,'Trombas');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221502,52,'Turvânia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221551,52,'Turvelândia');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221577,52,'Uirapuru');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221601,52,'Uruaçu');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221700,52,'Uruana');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221809,52,'Urutaí');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221858,52,'Valparaíso de Goiás');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5221908,52,'Varjão');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5222005,52,'Vianópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5222054,52,'Vicentinópolis');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5222203,52,'Vila Boa');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5222302,52,'Vila Propício');
INSERT INTO cities(ibge, state_id, nome) VALUES 
(5300108,53,'Brasília');